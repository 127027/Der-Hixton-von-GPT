"""Locked eight-policy comparison on one current three-year public-data snapshot."""
from __future__ import annotations

import argparse
import csv
import gzip
import hashlib
import json
import time
from collections import Counter, defaultdict
from dataclasses import asdict, fields
from datetime import UTC, datetime, timedelta
from decimal import Decimal as D
from pathlib import Path

import controls
import native_overlay
from hixton.backtest.models import CURRENT_COSTS, STRESS_COSTS, ExecutionRules
from hixton.backtest.portfolio import run_shared_portfolio_backtest
from hixton.backtest.reporting import source_fingerprint
from hixton.domain.market_rules import FILTER_DECIMALS
from hixton.domain.models import Candle, SignalAction
from hixton.domain.versions import strategy_definition

OUT = Path(__file__).resolve().parent
COSTS = {"current": CURRENT_COSTS, "stress": STRESS_COSTS, "impact": CURRENT_COSTS}
METHODS = ("controls.py", "native_overlay.py", "runner.py", "analyze.py")
CASE_FILES = frozenset(("Result.json", "Fills.json", "Trades.json", "Signals.json",
                        "Interventions.json", "Equity.csv.gz"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, payload):
    Path(path).write_text(json.dumps(payload, default=str, indent=2), encoding="utf-8")


def read(name):
    return json.loads((OUT / name).read_text(encoding="utf-8"))


def expected_identity(label, model):
    strategy = controls.definition(strategy_definition("v8r"), controls.CONFIGS[label])
    return {"variant": label, "cost": model,
            "contract_sha256": sha(OUT / "Study-Contract.json"),
            "context_sha256": sha(OUT / "Context.json"), "strategy_version": strategy.version}


def verified_case(dest, identity):
    complete_path, unknown_path = dest / "Complete.json", dest / "Unassessable.json"
    assert not (complete_path.exists() and unknown_path.exists()), "Conflicting case artifacts"
    if unknown_path.exists():
        unknown = json.loads(unknown_path.read_text())
        assert unknown["identity"] == identity
        assert str(unknown["reason"]).startswith("IMPACT_UNASSESSABLE")
        assert identity["cost"] == "impact"
        return unknown
    complete = json.loads(complete_path.read_text())
    assert complete["complete"] is True
    assert complete["identity"] == identity
    assert set(complete["files"]) == CASE_FILES
    assert all(sha(dest/name) == digest for name,digest in complete["files"].items())
    row = json.loads((dest / "Result.json").read_text())
    assert row["identity"] == identity
    assert row["technical_checks"]["cash_quantity_equity_and_chronology_pass"] is True
    return row


def freeze():
    context = read("Context.json")
    assert context["starting_cash_usdc"] == "1085.77093944"
    assert context["source_sha256_at_capture_end"] == source_fingerprint()
    _, evidence = native_overlay.load()
    _, overlay, diff = native_overlay.source_overlay()
    (OUT / "Frozen-Native-Overlay.py").write_text(overlay, encoding="utf-8")
    (OUT / "Native-Overlay.diff").write_text(diff, encoding="utf-8")
    contract = {
        "created_at_utc": datetime.now(UTC), "research_only": True,
        "pre_pnl_method_revision": "A09 required selector hash and strict completion/identity gates; no candidate performance observed before revision",
        "source_commit": context["source_commit"], "source_sha256": source_fingerprint(),
        "context_sha256": sha(OUT / "Context.json"),
        "candles_sha256": sha(OUT / "Candles.json.gz"),
        "methods_sha256": {name: sha(OUT / name) for name in METHODS},
        "overlay_file_sha256": sha(OUT / "Frozen-Native-Overlay.py"),
        "native_overlay_evidence": {k:v for k,v in evidence.items() if k != "diff"},
        "candidate_order": list(controls.CONFIGS),
        "candidates": {name: asdict(value) for name, value in controls.CONFIGS.items()},
        "cost_order": list(COSTS),
        "costs": {name: asdict(value) for name, value in COSTS.items()},
        "impact_sensitivity": {
            "formula": "current adverse rate + 0.001*sqrt(pre-fill notional/(0.01*previous closed-hour quote volume))",
            "buy_notional": "known quote budget before fill",
            "sell_notional": "owned rounded quantity * execution reference open before impact",
            "not_calibrated": True,
            "proxy_limit": "USDT historical proxy quote turnover is not historical USDC orderbook depth",
            "missing_volume_or_rate_ge_one": "case UNASSESSABLE, no cheap fallback, not eligible",
            "eligibility": "fully assessable; paired ending equity >= baseline and DD <= baseline",
        },
        "daily5_definition": {
            "basis": "native UTC-day start equity; realized plus unrealized PnL, fees and dust",
            "threshold": "closed equity <= 0.95*day start equity; first such close per UTC day",
            "execution": "queue all owned SELLs at next executable open, preserve earlier regular exits",
            "latch": "daily5_flat until next UTC day; daily5_flat24 until max(next UTC day,trigger+24h)",
            "unresolved_owned_exits": "continue blocking buys and re-queue exits after pause expiry",
            "guaranteed_maximum_loss": False,
        },
        "dd_step_definition": "new entries only: normal fraction below10%peakDD; .75 at10..20%; .50 at>=20%; existing ATR fraction multiplies, no forced rebalance",
        "cooldown_definition": "aggregate net realized cycle PnL incl partial exits; after final sale, losing coin blocked24h; check again after same-boundary exits",
        "liquidity_definition": "BUY budget capped at5% previous closed-hour quote turnover; never cap or silently block liquidation SELLs",
        "cmo_definition": "Core entry floor=max(previous floor,.20); preserve stricter floors and all other policy rules",
        "selection": {
            "technical_gates": ["complete reproducible native overlay baseline parity",
                                "ledger/chronology/price checks", "all three execution cases assessable"],
            "economic_gates": "ending equity >= baseline AND max DD <= baseline, separately in EACH of current,stress,impact",
            "ranking": "highest current-cost net PnL first, then smaller current-cost DD, then fixed candidate order",
            "no_eligible_improvement": "NO_CHANGE; no parameter rescue search",
            "winner_only_robustness": "12 already existing five-year validation paths, baseline vs selected winner, current and stress costs",
            "robustness_gates": "median paired net advantage>=0 under BOTH costs; >=7/12 normal nonworse; worst DD <= baseline under BOTH costs",
            "no_rescue_after_rejection": True,
        },
        "interpretation": ["known historical data; no truly unseen out-of-sample claim",
                           "24 predeclared three-year cases plus native original controls",
                           "all15 markets/roles, one shared starting capital, reinvested PnL",
                           "open ending positions marked, no assumed final sale",
                           "no actual historical orderbooks, outages, delistings or USDC depeg model"],
        "promotion": "only after winner passes historical and robustness gates plus complete same-head Backtest/Paper/Trial/Live parity, regression, A09 and A11 review; no Live activation by this research",
    }
    target = OUT / "Study-Contract.json"
    if target.exists():
        raise FileExistsError("Frozen contract already exists; never overwrite after observations")
    write(target, contract)
    print(json.dumps({"frozen": True, "contract_sha256": sha(target)}), flush=True)


def check_lock(require_approval=True):
    context, contract = read("Context.json"), read("Study-Contract.json")
    assert sha(OUT / "Context.json") == contract["context_sha256"]
    assert sha(OUT / "Candles.json.gz") == contract["candles_sha256"]
    assert source_fingerprint() == contract["source_sha256"]
    assert all(sha(OUT/name) == digest for name,digest in contract["methods_sha256"].items())
    if require_approval:
        approval = read("A09-Method-Approval.json")
        assert approval["approved"] is True
        assert approval["contract_sha256"] == sha(OUT / "Study-Contract.json")
    return context, contract


def load_data(context):
    with gzip.open(OUT / "Candles.json.gz", "rt", encoding="utf-8") as stream:
        raw = json.load(stream)
    data = {s: [Candle(**{**row,
        "open_time_utc": datetime.fromisoformat(row["open_time_utc"]),
        "close_time_utc": datetime.fromisoformat(row["close_time_utc"])}) for row in raw[s]]
        for s in context["symbols"]}
    rules = {s: ExecutionRules(**{k: D(v) if k in FILTER_DECIMALS else v
             for k,v in row.items()}) for s,row in context["execution_rules"].items()}
    return data, rules


def audit(result, data, *, warmup=400):
    sigs = {s.signal_id: s for s in result.signals}
    grouped = defaultdict(list)
    for fill in result.fills:
        signal = sigs[fill.signal_id]
        assert signal.candle_close_time_utc < fill.fill_time_utc
        assert fill.fill_time_utc == signal.candle_close_time_utc + timedelta(milliseconds=1)
        grouped[fill.fill_time_utc].append(fill)
    cash, owned = result.starting_cash, dict.fromkeys(data, D(0))
    max_participation, over5, missing = D(0), 0, 0
    for i, point in enumerate(result.equity_curve):
        at = result.report_start_utc + timedelta(hours=i)
        for fill in grouped[at]:
            s = sigs[fill.signal_id].symbol
            if fill.action is SignalAction.ENTER_LONG:
                cash -= fill.quote_value
                owned[s] += fill.base_quantity
            else:
                cash += fill.quote_value - fill.fee_quote_equivalent
                owned[s] -= fill.base_quantity
            previous = data[s][warmup+i-1]
            volume = D(str(previous.quote_volume))
            if volume > 0:
                ratio = fill.quote_value / volume
                max_participation = max(max_participation, ratio)
                over5 += int(ratio > D(".05"))
            else:
                missing += 1
        value = sum((q * D(str(data[s][warmup+i].close)) for s,q in owned.items()), D(0))
        assert cash >= 0 and min(owned.values()) >= 0
        assert abs(cash - point.cash) < D("1e-15")
        assert abs(value - point.position_value) < D("1e-15")
        assert abs(cash + value - point.equity) < D("1e-15")
    assert result.metrics.ending_equity == result.equity_curve[-1].equity
    return {"cash_quantity_equity_and_chronology_pass": True,
            "fills_checked": len(result.fills), "hours_checked": len(result.equity_curve),
            "max_previous_hour_participation": max_participation,
            "fills_above5pct_previous_hour_turnover": over5,
            "fills_missing_previous_quote_volume": missing}


def kwargs_for(context, data, rules, cost, definition):
    cash = D(context["starting_cash_usdc"])
    return dict(candles_by_symbol=data,
                report_start_utc=datetime.fromisoformat(context["report_start_utc"]),
                report_end_utc=datetime.fromisoformat(context["report_end_utc"]),
                starting_cash=cash, target_notional=(cash/2).quantize(D(".01")),
                slot_count=2, costs=cost, execution_rules=rules, strategy=definition,
                reinvest_profits=True, autonomous_spot=True)


def save_result(dest, result, controller, identity, data, seconds):
    dest.mkdir(parents=True, exist_ok=True)
    checks = audit(result, data)
    row = {"identity": identity, "metrics": asdict(result.metrics), "technical_checks": checks,
           "seconds": seconds, "research_only": True,
           "blocked_reasons": dict(Counter(s.rsplit(":",1)[-1] for s in result.blocked_signals)),
           "interventions": dict(Counter(e["kind"] for e in controller.events)),
           "open_symbols_at_end": result.open_symbols_at_end,
           "pending_signals_at_end": [asdict(s) for s in result.pending_signals_at_end],
           "not_a_guaranteed_loss_bound": True}
    write(dest / "Result.json", row)
    write(dest / "Fills.json", [asdict(f) for f in result.fills])
    write(dest / "Trades.json", [asdict(t) for t in result.trades])
    write(dest / "Signals.json", [asdict(s) for s in result.signals])
    write(dest / "Interventions.json", controller.events)
    with gzip.open(dest / "Equity.csv.gz", "wt", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["time_utc", "cash", "position_value", "equity"])
        writer.writerows((p.time_utc, p.cash, p.position_value, p.equity) for p in result.equity_curve)
    names = ("Result.json", "Fills.json", "Trades.json", "Signals.json", "Interventions.json", "Equity.csv.gz")
    write(dest / "Complete.json", {"identity": identity,
                                   "files": {n: sha(dest/n) for n in names}, "complete": True})
    return row


def run():
    context, contract = check_lock()
    data, rules = load_data(context)
    module, _ = native_overlay.load()
    base = strategy_definition("v8r")
    for label in contract["candidate_order"]:
        config = controls.CONFIGS[label]
        definition = controls.definition(base, config)
        for model in contract["cost_order"]:
            check_lock()
            dest = OUT / "runs" / f"{label}-{model}"
            identity = expected_identity(label, model)
            if (dest / "Complete.json").exists() or (dest / "Unassessable.json").exists():
                verified_case(dest, identity)
                continue
            controller = controls.Controls(config, impact=model=="impact")
            kwargs = kwargs_for(context, data, rules, COSTS[model], definition)
            began = time.monotonic()
            try:
                result = module.run_shared_portfolio_backtest(**kwargs, research_controller=controller)
            except ValueError as error:
                if not str(error).startswith("IMPACT_UNASSESSABLE"):
                    raise
                dest.mkdir(parents=True, exist_ok=True)
                write(dest / "Unassessable.json", {"identity": identity, "reason": str(error)})
                print(json.dumps({**identity, "unassessable": str(error)}), flush=True)
                continue
            if label == "current" and model != "impact":
                original = run_shared_portfolio_backtest(**kwargs)
                assert result == original
                write(OUT / f"Native-Parity-{model}.json", {
                    "contract_sha256": identity["contract_sha256"], "entire_result_equal": True,
                    "checked_fields": [f.name for f in fields(result)],
                    "original_native_metrics": asdict(original.metrics),
                    "fills": len(result.fills), "hours": len(result.equity_curve)})
            row = save_result(dest, result, controller, identity, data, time.monotonic()-began)
            print(json.dumps({"variant": label, "cost": model,
                              "ending_equity": str(result.metrics.ending_equity),
                              "dd": str(result.metrics.max_drawdown_pct),
                              "events": row["interventions"], "seconds": row["seconds"]}), flush=True)
    check_lock()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("operation", choices=("freeze", "run"))
    args = parser.parse_args()
    freeze() if args.operation == "freeze" else run()
