"""Curated public allowlist; never export account status, local DBs or credentials."""
from __future__ import annotations

import gzip
import json
import os
import shutil
import zipfile
from pathlib import Path

import runner

OUT = runner.OUT
ROOT = OUT.parent.parent
DEST = ROOT / "docs" / "research" / "risk-controls-20261026"


def chart(summary):
    os.environ["MPLCONFIGDIR"] = str(OUT / "mplcache")
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from datetime import datetime
    fig, axes = plt.subplots(2, 1, figsize=(11, 7), sharex=True,
                             gridspec_kw={"height_ratios": [2, 1]})
    for label in summary["rows"]:
        path = OUT / "runs" / f"{label}-current" / "Equity.csv.gz"
        import csv
        with gzip.open(path, "rt", encoding="utf-8") as stream:
            records = list(csv.DictReader(stream))
        times = [datetime.fromisoformat(row["time_utc"]) for row in records]
        equity = [float(row["equity"]) for row in records]
        peak, dd = equity[0], []
        for value in equity:
            peak = max(peak, value)
            dd.append(100 * (value / peak - 1))
        width = 2.5 if label == "current" else 1.1
        axes[0].plot(times, equity, label=label, lw=width, alpha=.9)
        axes[1].plot(times, dd, lw=width, alpha=.8)
    axes[0].set_title("Gleiche drei Jahre · gemeinsames Kapital · normale Kosten")
    axes[0].set_ylabel("Modell-Equity (USDC)")
    axes[1].set_ylabel("Schlusskurs-DD (%)")
    axes[0].legend(ncol=2, fontsize=8)
    for ax in axes:
        ax.grid(alpha=.2)
    fig.text(.5, .01, "Historische Simulation; keine Verlustgrenze oder Zukunftsprognose.",
             ha="center", fontsize=9)
    fig.tight_layout(rect=(0,.03,1,1))
    fig.savefig(OUT / "Vergleich.png", dpi=150)
    plt.close(fig)


def main():
    context, contract = runner.check_lock()
    summary = runner.read("Summary.json")
    selection = runner.read("Selection.json")
    assert summary["selection"] == selection
    # This exporter is for the no-change research conclusion. A successful product
    # candidate requires a separate implementation/release dossier instead.
    assert selection["winner"] == "current" and selection["decision"] == "NO_CHANGE"
    chart(summary)
    DEST.mkdir(parents=True, exist_ok=True)
    allowed = ("Bericht.md", "Einordnung.md", "Comparison.csv", "Vergleich.png", "Summary.json",
               "Study-Contract.json", "Selection.json", "Native-Parity-current.json",
               "Native-Parity-stress.json", "Native-Overlay.diff")
    for name in allowed:
        shutil.copyfile(OUT / name, DEST / name)
    report = (DEST / "Bericht.md").read_text(encoding="utf-8")
    for old,new in (("plus400h", "plus 400 Stunden"), ("Signale.10Core und3", "Signale. 10 Core und 3"),
                    ("mindestens24h", "mindestens 24 Stunden"), ("Verlust-Coin24h", "Verlust-Coin 24 Stunden"),
                    ("Was die5%", "Was die 5 %"), ("bei5%Verlust", "bei 5 % Verlust"),
                    ("bzw mindestens24h", "bzw. mindestens 24 Stunden"),
                    ("Offene Ausstiegspflichten bleiben gesperrt.",
                     "Solange Ausstiegspflichten offen sind, bleiben neue Käufe gesperrt; die Ausstiege werden weiter versucht.")):
        report = report.replace(old,new)
    (DEST / "Bericht.md").write_text(report, encoding="utf-8")
    attribution = json.loads((OUT / "A02-Rolling-Control" / "Attribution-Report.json").read_text())
    runner.write(DEST / "Rolling-Control-Evidence.json", {
        "original_attribution_report_sha256": runner.sha(OUT / "A02-Rolling-Control" / "Attribution-Report.json"),
        "original_attribution_artifacts_sha256": attribution["artifact_hashes"],
        "no_product_changes": attribution["no_product_changes"],
        "no_candidate_or_method_change": attribution["no_candidate_or_method_change"],
        "summary": "Old original trades/fills and every overlapping candle field reproduced; capital/filter/end-extension/new-flat-start effects separated. Raw original controls remain local.",
    })
    public_context = {key: context[key] for key in (
        "source_commit", "source_sha256_at_capture_start", "source_sha256_at_capture_end",
        "strategy", "report_start_utc", "report_end_utc", "warmup_start_utc", "warmup_bars",
        "report_hours", "starting_cash_usdc", "capital_status", "run_settings", "symbols",
        "core_symbols", "satellite_symbols", "active_shared_satellites", "shared_entry_universe",
        "execution_rules", "rules_observed_at_utc", "cost_models", "provenance_by_symbol",
        "snapshot_sha256_by_symbol", "candle_count_by_symbol", "limitations")}
    public_context["redaction"] = {
        "public_derived_specification": True,
        "original_context_sha256": contract["context_sha256"],
        "omitted": "private status snapshot, original local paths, account balance observation, capture DBs",
        "original_candle_pack_sha256": contract["candles_sha256"],
        "not_a_replacement_for_original_context_bytes": True,
        "seed_disclosure": "Owner-selected last confirmed comparison amount, not current live account claim",
    }
    runner.write(DEST / "Simulation-Spezifikation.json", public_context)
    methods = ("controls.py", "native_overlay.py", "runner.py", "analyze.py", "publish.py")
    with zipfile.ZipFile(DEST / "Methoden-Code.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in methods:
            archive.write(OUT / name, name)
        archive.writestr("README.txt", "Research-only. No product import or automatic Live activation. Exact rerun needs original frozen inputs, which stay local. Four execution/selection methods are contract-hash-bound; publish.py only formats/exports results. Native source reference and explicit overlay diff are supplied.\n")
    (DEST / ".gitattributes").write_text(
        "# Preserve frozen JSON/method bytes for published SHA-256 verification.\n"
        "* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n"
        "# Unified diff context lines intentionally contain one space.\n"
        "Native-Overlay.diff -whitespace\n", encoding="utf-8")
    (DEST / "README.md").write_text(
        "# Schutzregeln: Vergleich auf den letzten drei Jahren · 26.10.2026\n\n"
        "**Entscheidung: NO_CHANGE. Keine neue Handelsregel übernommen.**\n\n"
        "Acht vorab festgelegte Varianten des aktuellen Bots auf denselben15Marktreihen, "
        "demselben Zeitraum26.10.2023–26.10.2026 und gemeinsamem Vergleichsstartkapital1.085,77093944USDC "
        "mit Wiederanlage. NormaleKosten, Kostenstress und eine ausdrücklich unkalibrierte Liquiditätskosten-Sensitivität werden getrennt verglichen.\n\n"
        "- [Entscheidung, Tradeoffs und Erklärung der neuen Baseline](Einordnung.md)\n"
        "- [Alle Ergebnisse, Auswahl und Grenzen](Bericht.md)\n"
        "- [Alle Vergleichswerte](Comparison.csv) und [Equity-/Drawdown-Diagramm](Vergleich.png)\n"
        "- [Vorabvertrag](Study-Contract.json), [mechanische Auswahl](Selection.json), [Ergebnisübersicht](Summary.json)\n"
        "- [Öffentliche abgeleitete Simulationsspezifikation](Simulation-Spezifikation.json)\n"
        "- [Methodenquellen](Methoden-Code.zip), [ausdrücklicher nativer Researchdiff](Native-Overlay.diff), [Dateibindung](Public-Evidence.json)\n\n"
        "Die Baseline wurde gegen den unveränderten nativen Engine vollständig identisch geprüft "
        "([normal](Native-Parity-current.json), [Stress](Native-Parity-stress.json)). "
        "Forschungsregeln sind kein bereits eingebauter Livevertrag. Die5%-Schwelle ist keine garantierte Verlustobergrenze. "
        "Historische Proxykerzen, heutige Exchangefilter und fehlende historische Orderbücher begrenzen die Aussage. "
        "Der Startbetrag wurde ausdrücklich als zuletzt bestätigter Vergleichsseed gewählt, nicht als frischer Kontostand.\n\n"
        "Originale große Marktdatensätze, Ausführungskurven und private Statusdaten bleiben lokal; "
        "ihre Originalhashes sind gebunden. Keine Schlüssel, Passwörter oder Live-/Neustartänderungen.\n",
        encoding="utf-8")
    files = sorted(path.name for path in DEST.iterdir() if path.is_file() and path.name != "Public-Evidence.json")
    runner.write(DEST / "Public-Evidence.json", {
        "source_commit": contract["source_commit"], "source_sha256": contract["source_sha256"],
        "contract_sha256": runner.sha(OUT / "Study-Contract.json"),
        "context_sha256": contract["context_sha256"], "selection_sha256": runner.sha(OUT / "Selection.json"),
        "decision": "NO_CHANGE", "product_source_changed": False, "runtime_changed": False,
        "keys_or_private_account_snapshot_published": False,
        "files_sha256": {name: runner.sha(DEST/name) for name in files},
        "method_sources_sha256": {name: runner.sha(OUT/name) for name in methods},
        "raw_inputs_and_original_execution_records_remain_local": True,
    })
    print(json.dumps({"public_dir": str(DEST), "files": len(files)+1,
                      "bytes": sum(path.stat().st_size for path in DEST.iterdir() if path.is_file())}), flush=True)


if __name__ == "__main__":
    main()
