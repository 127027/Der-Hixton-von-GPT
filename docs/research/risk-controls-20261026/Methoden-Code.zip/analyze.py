"""Mechanical frozen-rule comparison. No search or candidate rescue."""
from __future__ import annotations

import csv
import json
from datetime import UTC, datetime
from decimal import Decimal as D

import runner

OUT = runner.OUT
LABELS = {
    "current": "Unveränderter Bot",
    "daily5_flat": "5%-Tagesausstieg, bis Tageswechsel pausieren",
    "daily5_flat24": "5%-Tagesausstieg, mindestens24h pausieren",
    "dd_step": "Neue Positionen bei Drawdown verkleinern",
    "loss_cooldown24": "Verlust-Coin24h pausieren",
    "liquidity5": "Kaufgröße nach vorherigem Stundenvolumen begrenzen",
    "cmo20": "Strengerer Core-Momentumfilter",
    "combined": "Alle neuen Schutzregeln kombiniert",
}


def load_case(label, model):
    dest = OUT / "runs" / f"{label}-{model}"
    return runner.verified_case(dest, runner.expected_identity(label, model))


def select():
    context, contract = runner.check_lock()
    rows = {label: {model:load_case(label,model) for model in contract["cost_order"]}
            for label in contract["candidate_order"]}
    gates = {}
    for label, cases in rows.items():
        checks = {}
        for model, case in cases.items():
            baseline = rows["current"][model]
            assessable = "metrics" in case and "metrics" in baseline
            checks[model] = {
                "assessable": assessable,
                "ending_nonworse": assessable and D(case["metrics"]["ending_equity"]) >= D(baseline["metrics"]["ending_equity"]),
                "dd_nonworse": assessable and D(case["metrics"]["max_drawdown_pct"]) <= D(baseline["metrics"]["max_drawdown_pct"]),
            }
        gates[label] = {"models": checks, "eligible": all(all(c.values()) for c in checks.values())}
    eligible = [label for label in contract["candidate_order"] if gates[label]["eligible"]]
    ranked = sorted(eligible, key=lambda label: (
        -D(rows[label]["current"]["metrics"]["net_pnl"]),
        D(rows[label]["current"]["metrics"]["max_drawdown_pct"]),
        contract["candidate_order"].index(label)))
    winner = ranked[0] if ranked else "current"
    selection = {
        "selected_at_utc": datetime.now(UTC),
        "contract_sha256": runner.sha(OUT / "Study-Contract.json"),
        "context_sha256": runner.sha(OUT / "Context.json"),
        "complete_cases": sum("metrics" in case for cases in rows.values() for case in cases.values()),
        "unassessable_cases": sum("metrics" not in case for cases in rows.values() for case in cases.values()),
        "gates": gates, "ranked_eligible": ranked, "winner": winner,
        "decision": "NO_CHANGE" if winner == "current" else "ROBUSTNESS_CHECK_REQUIRED",
        "product_promotion_allowed": False,
        "case_evidence_sha256": {
            f"{label}-{model}": {
                "file": "Complete.json" if "metrics" in case else "Unassessable.json",
                "sha256": runner.sha(OUT/"runs"/f"{label}-{model}"/
                    ("Complete.json" if "metrics" in case else "Unassessable.json"))}
            for label,cases in rows.items() for model,case in cases.items()},
        "no_unseen_real_data_claim": True,
    }
    target = OUT / "Selection.json"
    if target.exists():
        old = json.loads(target.read_text())
        assert {k:v for k,v in old.items() if k != "selected_at_utc"} == {
            k:v for k,v in selection.items() if k != "selected_at_utc"}
        selection = old
    else:
        runner.write(target, selection)
    return context, contract, rows, selection


def number(value, digits=2):
    return f"{D(str(value)):,.{digits}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def main():
    context, contract, rows, selection = select()
    summary = {
        "context": {k:context[k] for k in ("report_start_utc", "report_end_utc", "starting_cash_usdc", "capital_status", "run_settings", "symbols", "shared_entry_universe")},
        "selection": selection,
        "rows": rows,
        "source_commit": contract["source_commit"], "source_sha256": contract["source_sha256"],
        "strategy_changed": False, "runtime_changed": False, "orders_sent": False,
    }
    runner.write(OUT / "Summary.json", summary)
    with (OUT / "Comparison.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["variant", "execution_model", "ending_equity", "net_pnl", "max_dd_pct", "eligible"])
        for label,cases in rows.items():
            for model,case in cases.items():
                m = case.get("metrics", {})
                writer.writerow([label,model,m.get("ending_equity"),m.get("net_pnl"),m.get("max_drawdown_pct"),selection["gates"][label]["eligible"]])
    lines = ["# Risikoregeln auf den aktuellen letzten drei Jahren · 26.10.2026", "",
        "**Vorab festgelegter Vergleich, keine nachträgliche Parametersuche.**", "",
        f"Zeitraum: **{context['report_start_utc']} bis {context['report_end_utc']}**, plus400h Vorlauf. "
        f"Gemeinsames Startkapital **{number(context['starting_cash_usdc'],8)}USDC**, Start in Cash, Wiederanlage von Gewinnen/Verlusten. "
        "Der Benutzer hat ausdrücklich den zuletzt belegten Betrag als Vergleichsseed gewählt; er ist kein frisch bestätigter Kontostand.", "",
        "15 Profile liefern gemeinsam Signale.10Core und3 nominelle Shared-Filler bleiben erhalten; SUI/UNI sind weiterhin Research-only. "
        "Die tatsächliche Fillerfreigabe hängt zusätzlich von den bisherigen Profil-/Qualitäts-/Core-Prioritätsregeln ab.", "",
        "## Ergebnis bei normalen Kosten", "",
        "| Regel | End-USDC | Max. Schlusskurs-DD | Differenz zur Baseline |", "|---|---:|---:|---:|"]
    baseline = D(rows["current"]["current"]["metrics"]["ending_equity"])
    for label,cases in rows.items():
        m = cases["current"]["metrics"]
        lines.append(f"| {LABELS[label]} | {number(m['ending_equity'])} | {number(m['max_drawdown_pct'])}% | {number(D(m['ending_equity'])-baseline)} |")
    lines += ["", "## Gleiche Strategien unter höheren Ausführungskosten", "",
        "| Regel | Erhöhte Kosten: End-USDC / DD | Impact-Annahme: End-USDC / DD | Zulässig nach Vorabgates |", "|---|---:|---:|---|"]
    for label,cases in rows.items():
        values = []
        for model in ("stress", "impact"):
            m = cases[model].get("metrics")
            values.append(f"{number(m['ending_equity'])} / {number(m['max_drawdown_pct'])}%" if m else "nicht beurteilbar")
        lines.append(f"| {LABELS[label]} | {values[0]} | {values[1]} | {'ja' if selection['gates'][label]['eligible'] else 'nein'} |")
    lines += ["", "## Entscheidung", "",
        f"Auswahl: **{selection['winner']}**. Status: **{selection['decision']}**. "
        "Zulässig sind nur technisch einwandfreie Fälle mit mindestens demselben Endkapital und keinem größeren Drawdown unter jedem der drei vorab festgelegten Ausführungsmodelle. "
        "Innerhalb dieser Menge gilt der höchste normale Nettogewinn zuerst, Drawdown zweitens. "
        "Ein neuer Gewinner benötigt anschließend den festgelegten Fünfjahres-Robustheitsvergleich und vollständige gemeinsame Produktintegration samt unabhängiger QA/Governance. Keine Ersatzwahl nach Ablehnung.", "",
        "## Was die5% bedeuten", "",
        "Die Baseline pausiert neue Käufe bei5%Verlust gegenüber der UTC-Tagesbasis. Sie verkauft deshalb keine offenen Positionen automatisch und kann sich am selben Tag wieder freigeben. "
        "Die beiden neuen Tagesausstiege lösen bei abgeschlossener Stundenkerze aus, verkaufen frühestens zur folgenden ausführbaren Eröffnung und bleiben bis Tageswechsel bzw mindestens24h gesperrt. "
        "Offene Ausstiegspflichten bleiben gesperrt. Dies ist weder ein börsenseitiger Stop noch eine5%-Verlustgarantie: Gaps, Gebühren, illiquide Reste und Ausfälle können die Schwelle überschreiten.", "",
        "## Ausführungsannahmen und Grenzen", "",
        "Normale Kosten je Seite:10bpGebühr+2bpSpread+3bpSlippage. Stress:10+10+20bp. "
        "Die zusätzliche Impact-Sensitivität verwendet normale Kosten plus10bp×sqrt(Orderquote/(1%vorheriges abgeschlossenes Stunden-Quotevolumen)). "
        "Das ist eine ausdrücklich unkalibrierte Annahme, kein rekonstruiertes historisches Orderbuch. BUY verwendet das vor dem Fill bekannte Budget; SELL die gerundete eigene Menge mal Referenz-Eröffnung. "
        "Fehlendes Volumen oder nichtpositive Ausführbarkeit macht einen Fall unbeurteilbar; kein günstiger Ersatzfill.", "",
        "Historische USDC-Lücken sind transparent durch die bereits verwendete USDT-Kontinuitätsquelle ergänzt. Deren Preis und Quoteumsatz beweisen keine historische USDC-Liquidität. "
        "Aktuelle Exchangefilter sind eine einheitliche Annahme und keine historische Point-in-time-Rekonstruktion. Offene Endpositionen bleiben markiert, ohne erfundenen Schlussverkauf. "
        "Stundenschluss-DD kann höhere zwischenzeitliche Verluste unterschätzen. Internet-/Börsenausfälle, Delistings und USDC-Entkopplung sind durch diese Kursrechnung nicht vollständig abgedeckt.", "",
        "Es wurden weder echte Orders noch Neustarts, Livefreigaben oder Schlüsseländerungen ausgelöst. Ein Researchoverlay ist kein bereits implementierter Livevertrag.", ""]
    (OUT / "Bericht.md").write_text("\n".join(lines), encoding="utf-8")
    print(json.dumps({"winner": selection["winner"], "decision": selection["decision"],
                      "cases": selection["complete_cases"], "selection_sha256": runner.sha(OUT/"Selection.json")}), flush=True)


if __name__ == "__main__":
    main()
