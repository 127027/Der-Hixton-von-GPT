"""Predeclared causal research policies. Never imported by the product."""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field, replace
from datetime import UTC, datetime, timedelta
from decimal import Decimal as D

from hixton.domain.models import SignalAction
from hixton.domain.strategy import HixtonStrategy


@dataclass(frozen=True)
class ControlConfig:
    label: str
    daily_flatten: bool = False
    pause_24h: bool = False
    dd_step: bool = False
    loss_cooldown: bool = False
    liquidity_cap: bool = False
    cmo_floor: bool = False


CONFIGS = {
    "current": ControlConfig("current"),
    "daily5_flat": ControlConfig("daily5_flat", daily_flatten=True),
    "daily5_flat24": ControlConfig("daily5_flat24", daily_flatten=True, pause_24h=True),
    "dd_step": ControlConfig("dd_step", dd_step=True),
    "loss_cooldown24": ControlConfig("loss_cooldown24", loss_cooldown=True),
    "liquidity5": ControlConfig("liquidity5", liquidity_cap=True),
    "cmo20": ControlConfig("cmo20", cmo_floor=True),
    "combined": ControlConfig("combined", True, True, True, True, True, True),
}


def definition(base, config):
    if config.label == "current":
        return base
    profiles = base.coin_profiles
    if config.cmo_floor:
        profiles = tuple(
            replace(p, trade_policy=replace(p.trade_policy, cmo_floor=max(.20, p.trade_policy.cmo_floor)))
            if p.symbol not in base.satellite_symbols else p
            for p in profiles
        )
    return replace(base, version=base.version + "-RESEARCH-" + config.label,
                   paper_approved=False, coin_profiles=profiles)


@dataclass
class Controls:
    config: ControlConfig
    impact: bool = False
    day: str | None = None
    triggered_today: bool = False
    paused_until: datetime | None = None
    forced_owned: set = field(default_factory=set)
    cooldowns: dict = field(default_factory=dict)
    cycle_realized_pnl: dict = field(default_factory=dict)
    events: list = field(default_factory=list)

    def paused(self, at):
        return bool(self.forced_owned) or (self.paused_until is not None and at < self.paused_until)

    def on_close(self, *, points, positions, equity, day_start_equity, at):
        day = at.astimezone(UTC).date().isoformat()
        if day != self.day:
            self.day, self.triggered_today = day, False
        if (self.config.daily_flatten and not self.triggered_today
                and equity <= day_start_equity * D(".95")):
            self.triggered_today = True
            until = datetime.combine(at.astimezone(UTC).date() + timedelta(days=1),
                                     datetime.min.time(), tzinfo=UTC)
            if self.config.pause_24h:
                until = max(until, at + timedelta(hours=24))
            self.paused_until = max(self.paused_until or until, until)
            self.forced_owned.update(positions)
            self.events.append({"at": at, "kind": "DAILY_5_TRIGGER", "equity": equity,
                                "day_start_equity": day_start_equity, "pause_until": until,
                                "owned_symbols": sorted(positions)})
        self.forced_owned.intersection_update(positions)
        queued = []
        for symbol in sorted(self.forced_owned):
            point = points[symbol]
            sig = HixtonStrategy.signal_for(replace(point, flip_down=True, flip_up=False), is_long=True)
            if sig is not None:
                identifier = hashlib.sha256(
                    f"RESEARCH_DAILY_5|{symbol}|{at.isoformat()}".encode()).hexdigest()
                queued.append(replace(sig, signal_id=identifier))
        return queued

    def exposure(self, *, equity, high_water):
        if not self.config.dd_step:
            return D(1)
        dd = (high_water - equity) / high_water * 100
        return D(".50") if dd >= 20 else D(".75") if dd >= 10 else D(1)

    def exit_partial(self, *, cycle_id, pnl):
        self.cycle_realized_pnl[cycle_id] = self.cycle_realized_pnl.get(cycle_id, D(0)) + pnl

    def exit_completed(self, *, symbol, cycle_id, pnl, at):
        self.forced_owned.discard(symbol)
        total = self.cycle_realized_pnl.pop(cycle_id, D(0)) + pnl
        if self.config.loss_cooldown and total < 0:
            self.cooldowns[symbol] = at + timedelta(hours=24)
            self.events.append({"at": at, "kind": "LOSS_COOLDOWN", "symbol": symbol,
                                "cycle_realized_pnl": total, "until": self.cooldowns[symbol]})

    def filter_entries(self, entries, *, at, blocked):
        accepted = []
        for sig in entries:
            if self.config.loss_cooldown and at < self.cooldowns.get(sig.symbol, at):
                blocked.append(f"{sig.signal_id}:RESEARCH_LOSS_COOLDOWN_24H")
            else:
                accepted.append(sig)
        return accepted

    def budget(self, *, budget, previous, symbol, at):
        if not self.config.liquidity_cap:
            return budget
        volume = D(str(previous.quote_volume))
        if not volume.is_finite() or volume < 0:
            raise ValueError("LIQUIDITY_INVALID_CLOSED_VOLUME")
        capped = min(budget, volume * D(".05"))
        if capped < budget:
            self.events.append({"at": at, "kind": "LIQUIDITY_BUY_CAP", "symbol": symbol,
                                "uncapped": budget, "capped": capped,
                                "previous_closed_quote_volume": volume})
        return capped

    def adverse_rate(self, *, costs, notional, previous):
        if not self.impact:
            return costs.adverse_price_rate
        if not notional.is_finite() or notional < 0:
            raise ValueError("IMPACT_UNASSESSABLE_INVALID_NOTIONAL")
        if notional == 0:
            return costs.adverse_price_rate
        volume = D(str(previous.quote_volume))
        if not volume.is_finite() or volume <= 0:
            raise ValueError("IMPACT_UNASSESSABLE_MISSING_PREVIOUS_QUOTE_VOLUME")
        # Explicit uncalibrated sensitivity: +10bp at 1% previous-hour turnover.
        additional = D(".001") * (notional / (volume * D(".01"))).sqrt()
        rate = costs.adverse_price_rate + additional
        if rate >= 1:
            raise ValueError("IMPACT_UNASSESSABLE_COST_RATE_GE_ONE")
        return rate


def finish_pending(controller, *, pending, forced, signals):
    exits = {s.symbol for s in pending if s.action is SignalAction.EXIT_LONG}
    for sig in forced:
        if sig.symbol not in exits:
            pending = [s for s in pending if not
                       (s.symbol == sig.symbol and s.action is SignalAction.ENTER_LONG)]
            signals.append(sig)
            pending.append(sig)
    return pending
