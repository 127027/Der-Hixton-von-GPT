"""Small exact source overlay, isolated from product imports and runtime files.

Unmodified native chronological ledger/indicators, with seven explicit hooks.
The zero-control overlay must reproduce the original native result exactly.
"""
from __future__ import annotations

import difflib
import hashlib
import sys
import types
from pathlib import Path

import controls
import hixton.backtest.portfolio as original

OUT = Path(__file__).resolve().parent


def source_overlay():
    path = Path(original.__file__)
    source = path.read_text(encoding="utf-8")
    replacements = [
        ("    allowed_entry_symbols: frozenset[str] | None = None,\n",
         "    allowed_entry_symbols: frozenset[str] | None = None,\n"
         "    research_controller=None,\n"),
        ("    cash = starting_cash\n",
         "    controller = research_controller\n    assert controller is not None\n"
         "    cash = starting_cash\n"),
        ("            entries = [signal for signal in pending if signal.action is SignalAction.ENTER_LONG]\n",
         "            entries = [signal for signal in pending if signal.action is SignalAction.ENTER_LONG]\n"
         "            entries = controller.filter_entries(entries, at=open_time, blocked=blocked)\n"),
        ("            for signal in entries:\n",
         "            for signal in entries:\n"
         "                if not controller.filter_entries([signal], at=open_time, blocked=blocked):\n"
         "                    continue\n"),
        ("                    cash += net\n",
         "                    controller.exit_partial(cycle_id=trim_position.signal.signal_id, pnl=net-basis)\n"
         "                    cash += net\n"),
        ("                del positions[signal.symbol]\n\n            for signal in exits:",
         "                controller.exit_completed(symbol=signal.symbol, cycle_id=open_trade.signal.signal_id,\n"
         "                    pnl=realized_pnl, at=open_time)\n"
         "                del positions[signal.symbol]\n\n            for signal in exits:"),
        ("                    capital_fraction=capital_exposure_fraction,\n",
         "                    capital_fraction=capital_exposure_fraction * controller.exposure(\n"
         "                        equity=closed_equity, high_water=closed_high_water),\n"),
        ("                reference = _d(candles[signal.symbol].open)\n"
         "                fill_price = reference * (ONE + costs.adverse_price_rate)\n",
         "                budget = controller.budget(budget=budget,\n"
         "                    previous=previous_points[signal.symbol].candle, symbol=signal.symbol, at=open_time)\n"
         "                reference = _d(candles[signal.symbol].open)\n"
         "                fill_price = reference * (ONE + controller.adverse_rate(costs=costs,\n"
         "                    notional=budget, previous=previous_points[signal.symbol].candle))\n"),
        ("                reference = _d(candles[signal.symbol].open)\n"
         "                fill_price = reference * (ONE - costs.adverse_price_rate)\n"
         "                sell_quantity = round_market_quantity(open_trade.quantity, rule)\n",
         "                reference = _d(candles[signal.symbol].open)\n"
         "                sell_quantity = round_market_quantity(open_trade.quantity, rule)\n"
         "                fill_price = reference * (ONE - controller.adverse_rate(costs=costs,\n"
         "                    notional=sell_quantity*reference, previous=previous_points[signal.symbol].candle))\n"),
        ("                    price = reference * (ONE - costs.adverse_price_rate)\n",
         "                    price = reference * (ONE - controller.adverse_rate(costs=costs,\n"
         "                        notional=quantity*reference, previous=point.candle))\n"),
        ("            new_pending: list[Signal] = []\n",
         "            forced = controller.on_close(points=points, positions=positions, equity=equity,\n"
         "                day_start_equity=risk_state.day_start_equity_usdc,\n"
         "                at=max(candle.close_time_utc for candle in row))\n"
         "            daily_paused = daily_paused or controller.paused(max(candle.close_time_utc for candle in row))\n"
         "            new_pending: list[Signal] = []\n"),
        ("            pending = new_pending\n",
         "            pending = finish_pending(controller, pending=new_pending, forced=forced, signals=signals)\n"),
    ]
    changed = source
    for old, new in replacements:
        if changed.count(old) != 1:
            raise ValueError(f"Overlay anchor is not unique: {old!r}")
        changed = changed.replace(old, new)
    diff = "".join(difflib.unified_diff(source.splitlines(True), changed.splitlines(True),
                   fromfile="native-portfolio.py", tofile="research-overlay.py"))
    return source, changed, diff


def load():
    source, changed, diff = source_overlay()
    module = types.ModuleType("hixton_research_risk_overlay")
    module.__file__ = str(OUT / "Frozen-Native-Overlay.py")
    module.finish_pending = controls.finish_pending
    sys.modules[module.__name__] = module
    exec(compile(changed, module.__file__, "exec"), module.__dict__)
    return module, {"native_sha256": hashlib.sha256(source.encode()).hexdigest(),
                    "overlay_sha256": hashlib.sha256(changed.encode()).hexdigest(),
                    "diff": diff}
