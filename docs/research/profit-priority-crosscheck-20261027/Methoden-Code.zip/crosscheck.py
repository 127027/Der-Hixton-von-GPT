"""Exactly ten unchanged-native crosschecks; no selection, overlays or runtime access."""
from __future__ import annotations
import argparse,csv,gzip,hashlib,json,os,subprocess,time
from dataclasses import asdict
from datetime import UTC,datetime
from decimal import Decimal as D,ROUND_DOWN
from pathlib import Path
from hixton.backtest.engine import candle_snapshot_sha256
from hixton.backtest.models import CURRENT_COSTS,STRESS_COSTS,ExecutionRules
from hixton.backtest.portfolio import run_shared_portfolio_backtest
from hixton.backtest.reporting import source_fingerprint
from hixton.data.quality import audit_candles
from hixton.domain.market_rules import FILTER_DECIMALS
from hixton.domain.models import Candle
from hixton.domain.versions import V8_DOGE50_PAPER_STRATEGY,strategy_definition
OUT=Path(__file__).resolve().parent;RESEARCH=OUT.parent
OLD=RESEARCH/'anchor-comparison-20261024';NEW=RESEARCH/'risk-controls-20261026'
SOURCE='fb9c47bf2ffe2de8464fbfb083a3bcc3e94ad1fa6cb1259a86e8281a5c5e5efe'
SEED=D('1092.05773944');HEAD='48a3cd9264c41be730254a33b04d20c8f2e6c64b'
ARTIFACTS=('Result.json','Fills.json','Trades.json','Signals.json','Equity.csv.gz')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_text(encoding='utf-8'))
def write(p,x):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,default=str,indent=2),encoding='utf-8');t.replace(p)
def definitions():return {'original_doge50':V8_DOGE50_PAPER_STRATEGY,'current_v6':strategy_definition('v8r')}
def paths():return {'original_32k':OLD/'old_doge50-Candles.json.gz','current_26oct':NEW/'Candles.json.gz'}
def cases():
 rows=[{'name':f'{window}--{rule}--{cost}','window':window,'definition':rule,'cost':cost,'seed':str(SEED),'filters':'fresh_26oct'}
       for window in paths() for rule in definitions() for cost in ('current','stress')]
 rows += [{'name':'control-original32k','window':'original_32k','definition':'original_doge50','cost':'current','seed':str(SEED),'filters':'original_legacy4'},
          {'name':'control-known11k','window':'current_26oct','definition':'current_v6','cost':'current','seed':'1085.77093944','filters':'fresh_26oct'}]
 assert len(rows)==10
 return rows

def contract_payload():
 ctx=read(NEW/'Context.json');manifest=read(OLD/'old_doge50-Original-Manifest.json');prior=read(OLD/'Comparison-Contract.json')
 defs=definitions();assert defs['current_v6'].config_payload()==ctx['strategy']
 assert defs['original_doge50'].config_payload()==prior['definitions']['older_doge50']
 return {'created_at_utc':datetime.now(UTC),'source_commit':HEAD,'source_sha256':SOURCE,
 'script_sha256':sha(Path(__file__)),'no_overlay_or_indicator_cache':True,'native_function':'hixton.backtest.portfolio.run_shared_portfolio_backtest',
 'windows':{'original_32k':{'report_start_utc':manifest['data']['report_start_utc'],'report_end_utc':manifest['data']['report_end_utc'],
   'snapshot_sha256_by_symbol':manifest['data']['snapshot_sha256_by_symbol']},
  'current_26oct':{'report_start_utc':ctx['report_start_utc'],'report_end_utc':ctx['report_end_utc'],'snapshot_sha256_by_symbol':ctx['snapshot_sha256_by_symbol']}},
 'strategy_definitions':{k:v.config_payload() for k,v in defs.items()},
 'execution_rules_fresh_26oct':ctx['execution_rules'],'execution_rules_original_legacy4':prior['original_legacy_rules'],
 'costs':{'current':asdict(CURRENT_COSTS),'stress':asdict(STRESS_COSTS)},
 'settings':{'initial_positions':'FLAT','slot_count':2,'reinvest_profits':True,'autonomous_spot':True,'gap_fillers_enabled':True,'warmup_bars':400},
 'cases':cases(),'input_files_sha256':{str(p):sha(p) for p in [*paths().values(),NEW/'Context.json',OLD/'old_doge50-Original-Manifest.json',OLD/'Comparison-Contract.json',OLD/'Anchor-Retrieval.json',
   OLD/'old_doge50-original_control-older_doge50-current-Result.json',NEW/'runs/current-current/Result.json',NEW/'Native-Parity-current.json']},
 'known_controls':{'original32k_ending':'32469.38840320931655000000','original32k_dd':'39.13365517898558214268171784',
  'known11k_ending':'11004.17713294658555000000','known11k_dd':'38.23110102621364667771478231'},
 'scope':'Answer old/new data versus old/current strategy, same original seed. Exactly10native cases; no candidate optimization, window selection, product promotion or trading action.',
 'ranking_note':'Human preference: net USDC first, DD second; this crosscheck is explanation only and imposes no DD-nonregression exclusion.',
 'prior_evidence':'Old32k and latest11k windows/results already observed. No untouched OOS claim.',
 'limitations':['Current filters on historical candles, not historical point-in-time rules.',
 'Historical USDT proxy candles retained with explicit original source metadata. No historical USDC orderbook model.',
 'Fixed400h initialization and initially-flat rolling starts can change trends, trade competition and compounding.',
 'No additional execution-impact model; normal/stress assumptions are compared consistently, not verified real account costs.']}

def freeze():
 assert source_fingerprint()==SOURCE
 assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==HEAD
 assert not (OUT/'Contract.json').exists(),'Frozen contract cannot be overwritten.'
 write(OUT/'Contract.json',contract_payload())
 print('CONTRACT',sha(OUT/'Contract.json'),flush=True)

def locked():
 c=read(OUT/'Contract.json');assert c['script_sha256']==sha(Path(__file__))
 assert source_fingerprint()==c['source_sha256']==SOURCE
 assert all(sha(p)==h for p,h in c['input_files_sha256'].items())
 assert [{**x} for x in c['cases']]==cases()
 assert all(definitions()[k].config_payload()==v for k,v in c['strategy_definitions'].items())
 return c

def load(c):
 datasets={};proof={}
 for window,path in paths().items():
  with gzip.open(path,'rt',encoding='utf-8') as f:raw=json.load(f)
  symbols=definitions()['current_v6'].symbols
  assert set(raw)==set(symbols), 'All15profile contexts required'
  data={s:[Candle(**{**r,'open_time_utc':datetime.fromisoformat(r['open_time_utc']),'close_time_utc':datetime.fromisoformat(r['close_time_utc'])}) for r in rows] for s in symbols for rows in [raw[s]]}
  hashes={s:candle_snapshot_sha256(rows) for s,rows in data.items()}
  assert hashes==c['windows'][window]['snapshot_sha256_by_symbol']
  for s,rows in data.items():
   audit_candles(rows,expected_symbol=s,expected_start=rows[0].open_time_utc,expected_end_exclusive=datetime.fromisoformat(c['windows'][window]['report_end_utc'])).require_valid()
   assert len(rows)==26704
  datasets[window]=data;proof[window]={'all15_snapshot_hashes_match':True,'bars_by_symbol':{s:len(rows) for s,rows in data.items()},'sha256_by_symbol':hashes}
 write(OUT/'Input-Verification.json',{'contract_sha256':sha(OUT/'Contract.json'),'snapshots':proof})
 return datasets

def ledger(result,data):
 lookup={s.signal_id:s for s in result.signals};fills={}
 for f in result.fills:
  assert lookup[f.signal_id].candle_close_time_utc<f.fill_time_utc
  fills.setdefault(f.fill_time_utc,[]).append(f)
 cash=result.starting_cash;owned={s:D(0) for s in data};offset=400;maxerr=D(0)
 for i,p in enumerate(result.equity_curve):
  at=data[result.symbols[0]][offset+i].open_time_utc
  for f in fills.get(at,[]):
   sym=lookup[f.signal_id].symbol
   if f.action.value=='ENTER_LONG':cash-=f.quote_value;owned[sym]+=f.base_quantity
   else:cash+=f.quote_value-f.fee_quote_equivalent;owned[sym]-=f.base_quantity
  assert cash>=0 and min(owned.values())>=0
  equity=cash+sum((q*D(str(data[s][offset+i].close)) for s,q in owned.items()),D(0))
  err=abs(equity-p.equity);maxerr=max(maxerr,err);assert err<D('1e-15') and cash==p.cash
 peak=result.equity_curve[0].equity;dd=D(0)
 for p in result.equity_curve:
  peak=max(peak,p.equity);dd=max(dd,(peak-p.equity)/peak*100)
 assert abs(dd-result.metrics.max_drawdown_pct)<D('1e-20')
 return {'cash_quantity_equity_and_chronology_pass':True,'max_money_error_usdc':str(maxerr),'recomputed_max_dd':str(dd)}

def run():
 if os.name=='nt':
  import ctypes
  from ctypes import wintypes
  kernel=ctypes.WinDLL('kernel32');kernel.GetCurrentProcess.restype=wintypes.HANDLE
  kernel.SetPriorityClass.argtypes=[wintypes.HANDLE,wintypes.DWORD];kernel.SetPriorityClass(kernel.GetCurrentProcess(),0x4000)
 c=locked();data=load(c);defs=definitions();costs={'current':CURRENT_COSTS,'stress':STRESS_COSTS}
 rules={k:{s:ExecutionRules(**{f:D(v) if f in FILTER_DECIMALS else v for f,v in r.items()}) for s,r in c['execution_rules_'+k].items()} for k in ('fresh_26oct','original_legacy4')}
 for case in c['cases']:
  locked();dest=OUT/'runs'/case['name'];dest.mkdir(parents=True,exist_ok=True)
  identity={**case,'contract_sha256':sha(OUT/'Contract.json'),'source_sha256':SOURCE}
  if (dest/'Complete.json').exists():
   complete=read(dest/'Complete.json');assert complete['identity']==identity and complete['complete'] is True
   assert set(complete['files'])==set(ARTIFACTS)
   assert all(sha(dest/name)==h for name,h in complete['files'].items());continue
  started=time.monotonic();w=c['windows'][case['window']];seed=D(case['seed'])
  result=run_shared_portfolio_backtest(candles_by_symbol=data[case['window']],report_start_utc=datetime.fromisoformat(w['report_start_utc']),
   report_end_utc=datetime.fromisoformat(w['report_end_utc']),starting_cash=seed,target_notional=(seed/2).quantize(D('.01'),rounding=ROUND_DOWN),
   slot_count=2,costs=costs[case['cost']],execution_rules=rules[case['filters']],strategy=defs[case['definition']],reinvest_profits=True,autonomous_spot=True)
  native_done=time.monotonic();checks=ledger(result,data[case['window']])
  if case['name']=='control-original32k':
   assert result.metrics.ending_equity==D(c['known_controls']['original32k_ending'])
   assert result.metrics.max_drawdown_pct==D(c['known_controls']['original32k_dd'])
  if case['name']=='control-known11k':
   assert result.metrics.ending_equity==D(c['known_controls']['known11k_ending'])
   assert result.metrics.max_drawdown_pct==D(c['known_controls']['known11k_dd'])
  row={'identity':identity,'metrics':asdict(result.metrics),'checks':checks,'window':w,'strategy_version':defs[case['definition']].version,
   'native_unmodified':True,'data_snapshot_sha256_by_symbol':result.data_snapshot_sha256_by_symbol,
   'open_symbols_at_end':result.open_symbols_at_end,'daily_paused_bars':result.daily_paused_bars,
   'timing':{'native_seconds':native_done-started,'total_seconds':time.monotonic()-started}}
  write(dest/'Result.json',row);write(dest/'Fills.json',[asdict(x) for x in result.fills]);write(dest/'Trades.json',[asdict(x) for x in result.trades]);write(dest/'Signals.json',[asdict(x) for x in result.signals])
  with gzip.open(dest/'Equity.csv.gz','wt',encoding='utf-8',newline='') as f:
   writer=csv.writer(f);writer.writerow(['time_utc','equity','cash','position_value']);writer.writerows((p.time_utc,p.equity,p.cash,p.position_value) for p in result.equity_curve)
  locked();write(dest/'Complete.json',{'identity':identity,'complete':True,'files':{name:sha(dest/name) for name in ARTIFACTS}})
  print(json.dumps({'case':case['name'],'ending_usdc':str(result.metrics.ending_equity),'dd_pct':str(result.metrics.max_drawdown_pct),'seconds':row['timing']['total_seconds']}),flush=True)
 summary=[]
 for case in c['cases']:
  dest=OUT/'runs'/case['name'];complete=read(dest/'Complete.json');assert set(complete['files'])==set(ARTIFACTS);assert complete['complete'] and all(sha(dest/n)==h for n,h in complete['files'].items())
  summary.append({'case':case,'metrics':read(dest/'Result.json')['metrics'],'complete_sha256':sha(dest/'Complete.json')})
 write(OUT/'Results.json',{'contract_sha256':sha(OUT/'Contract.json'),'all10_complete':True,'case_count':10,'cases':summary})

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('mode',choices=('freeze','run'));args=parser.parse_args()
 freeze() if args.mode=='freeze' else run()
