"""Publish a bounded explanatory comparison; never change trading rules."""
from __future__ import annotations

import csv
import hashlib
import json
import shutil
import zipfile
from decimal import Decimal as D
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent.parent
PUB = ROOT / "docs" / "research" / "profit-priority-crosscheck-20261027"


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def number(value, digits=2):
    return f"{D(str(value)):,.{digits}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def main():
    contract, results = read(OUT / "Contract.json"), read(OUT / "Results.json")
    assert results["all10_complete"] is True and results["case_count"] == 10
    assert results["contract_sha256"] == sha(OUT / "Contract.json")
    assert sha(OUT / "crosscheck.py") == contract["script_sha256"]
    expected_names = {c["name"] for c in contract["cases"]}
    assert {r["case"]["name"] for r in results["cases"]} == expected_names
    for row in results["cases"]:
        dest = OUT / "runs" / row["case"]["name"]
        complete = read(dest / "Complete.json")
        assert complete["complete"] is True
        assert sha(dest / "Complete.json") == row["complete_sha256"]
        assert set(complete["files"]) == {"Result.json", "Fills.json", "Trades.json", "Signals.json", "Equity.csv.gz"}
        assert all(sha(dest/name) == h for name,h in complete["files"].items())
        saved = read(dest / "Result.json")
        assert saved["metrics"] == row["metrics"]
    cases = {r["case"]["name"]: r for r in results["cases"]}
    def metric(window, rule, cost):
        return cases[f"{window}--{rule}--{cost}"]["metrics"]
    old = metric("original_32k", "original_doge50", "current")
    today = metric("original_32k", "current_v6", "current")
    new_old = metric("current_26oct", "original_doge50", "current")
    new_today = metric("current_26oct", "current_v6", "current")
    delta = D(today["ending_equity"]) - D(old["ending_equity"])
    dd_delta = D(old["max_drawdown_pct"]) - D(today["max_drawdown_pct"])
    PUB.mkdir(parents=True, exist_ok=True)
    with (PUB / "Comparison.csv").open("w", encoding="utf-8", newline="") as stream:
        writer = csv.writer(stream)
        writer.writerow(["case", "window", "rules", "costs", "starting_usdc", "end_usdc", "net_pnl_usdc", "max_dd_pct", "filters"])
        for row in results["cases"]:
            c, m = row["case"], row["metrics"]
            writer.writerow([c["name"], c["window"], c["definition"], c["cost"], c["seed"],
                             m["ending_equity"], m["net_pnl"], m["max_drawdown_pct"], c["filters"]])
    shutil.copyfile(OUT / "Results.json", PUB / "Results.json")
    shutil.copyfile(OUT / "A09" / "Posthoc-Profit-Rerank.json", PUB / "Posthoc-Profit-Rerank.json")
    spec = {k:v for k,v in contract.items() if k != "input_files_sha256"}
    spec["input_files_sha256"] = {}
    for local_name,h in contract["input_files_sha256"].items():
        logical = local_name.replace("\\", "/")
        while "//" in logical:
            logical = logical.replace("//", "/")
        assert "/research/" in logical
        logical = "research/" + logical.split("/research/",1)[1]
        spec["input_files_sha256"][logical] = h
    spec["redaction"] = {"derived_public_specification": True,
        "original_contract_sha256": sha(OUT / "Contract.json"),
        "absolute_local_paths_removed": True,
        "not_a_replacement_for_original_contract_bytes": True,
        "model_seed_not_current_account_balance": True,
        "raw_inputs_and_original_execution_files_remain_local": True}
    write(PUB / "Comparison-Specification.json", spec)
    methods = ("crosscheck.py", "publish.py")
    with zipfile.ZipFile(PUB / "Methoden-Code.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name in methods:
            archive.write(OUT / name, name)
        archive.writestr("README.txt", "Research-only native comparison, no strategy deployment. Exact rerun requires the original frozen local datasets/manifests/results and product source commit48a3cd9264c41be730254a33b04d20c8f2e6c64b. Public specification redacts local paths and does not replace original contract bytes. No keys or account snapshots included.\n")
    lines = ["# Heutiger Bot auf den ursprünglichen 32k-Daten · 27.10.2026", "",
        f"**Ja: Die heutigen Regeln ergeben auf den ursprünglichen Daten {number(today['ending_equity'])} USDC statt {number(old['ending_equity'])} USDC.**", "",
        "Die heutigen Regeln sind die unveränderte aktive15-Profil-Strategie `HIXTON-V8-LINK8-ATR075-DOGE50-DD10-ETH8-DIV32-CLOSECAP-PAPER-6`. "
        "Das interne Label `current_v6` bezeichnet hier ihre Versions-Endnummer6, nicht den eingefrorenen Zehncoin-V6-Anker. "
        "Die ältere Vergleichsstrategie ist `HIXTON-V8-LINK8-ATR075-DOGE50-PAPER-2`.", "",
        "## Regeln und Daten getrennt verglichen", "",
        "Für alle acht Kreuzfälle gelten derselbe ursprüngliche Startbetrag **1.092,05773944 USDC**, "
        "dieselben aktuellen öffentlichen Exchangefilter vom26.10., dieselben15 Marktreihen/Rollen, "
        "je400 Stunden Vorlauf, Start ohne Positionen und vollständige Wiederanlage. "
        "Jedes Datenfenster umfasst exakt drei Kalenderjahre. Es gibt weder Overlay noch Indikatorcache oder neue Parametersuche.", "",
        "| Eingefrorenes Datenfenster | Alte DOGE50-Regeln: End-USDC / DD | Heutige Regeln: End-USDC / DD |", "|---|---:|---:|",
        f"| 11.10.2023 19:00–11.10.2026 19:00 UTC | {number(old['ending_equity'])} / {number(old['max_drawdown_pct'])}% | **{number(today['ending_equity'])} / {number(today['max_drawdown_pct'])}%** |",
        f"| 26.10.2023 14:00–26.10.2026 14:00 UTC | {number(new_old['ending_equity'])} / {number(new_old['max_drawdown_pct'])}% | **{number(new_today['ending_equity'])} / {number(new_today['max_drawdown_pct'])}%** |", "",
        f"Auf dem ursprünglichen32k-Fenster sind das **{number(delta)} USDC mehr Endkapital und {number(dd_delta)} Prozentpunkte weniger maximaler Drawdown**. "
        "Auf dem neueren Fenster schneiden die heutigen Regeln ebenfalls profitabler ab. "
        "Eine Rückkehr zu den alten Regeln würde auf diesem neueren Fenster den alten32k-Betrag nicht wiederherstellen.", "",
        "## Gleicher Vergleich unter erhöhten Kosten", "",
        "| Datenfenster | Alte Regeln: End-USDC / DD | Heutige Regeln: End-USDC / DD |", "|---|---:|---:|"]
    for window, label in (("original_32k", "Originales32k-Fenster"), ("current_26oct", "Neueres26Oct-Fenster")):
        a,b = metric(window,"original_doge50","stress"),metric(window,"current_v6","stress")
        lines.append(f"| {label} | {number(a['ending_equity'])} / {number(a['max_drawdown_pct'])}% | {number(b['ending_equity'])} / {number(b['max_drawdown_pct'])}% |")
    lines += ["", "Normale Kosten je Seite:10bp Gebühren+2bpSpread+3bpSlippage. Stress:10+10+20bp. "
        "Es wird kein BNB-Rabatt unterstellt. Endkapital ist die markierte Modell-Equity einschließlich noch offener Bestände/Dust, kein erzwungener Schlussverkauf.", "",
        "## Warum der andere Bericht nur etwa11k ausweist", "",
        "Die bekannten **11.004,18 USDC** sind zusätzlich mit ihrem damaligen Vergleichsstartbetrag **1.085,77093944 USDC** exakt reproduziert. "
        "Die11.069,13 in der gemeinsamen Tabelle verwenden dagegen bewusst denselben1.092,05773944-USDC-Startbetrag wie der alte32k-Vergleich. "
        "Beide sind simulierte Kapitalpfade, keine aktuelle Binance-Guthabenabfrage.", "",
        "Das Verschieben des Dreijahresfensters verändert den flachen Anfangszustand, den400-Stunden-Indikatorvorlauf, die ersten verfügbaren Einstiege und danach den gesamten Wiederanlagepfad. "
        "Die vorherige [native Zerlegung des21k/11k-Unterschieds](../risk-controls-20261026/Einordnung.md) ist unverändert maßgeblich: "
        "Das bloße Weiterlaufen bei altem Start änderte22.526,13 auf21.793,40 USDC; der spätere flache Start samt neuer Initialisierung ergab11.004,18. "
        "399.465 überlappende Kerzen waren vollständig identisch. Der frühe AVAX-Einstieg vom26.10.2023 08:00 UTC ist ein konkreter Auslöser; die gesamte spätere Differenz ist nicht als isolierter Gewinn eines einzelnen Trades belegt.", "",
        "**Die am26.10. getesteten zusätzlichen Schutzregeln wurden nie in den aktiven Bot übernommen. "
        "Der große Unterschied zwischen den zwei Fenstern ist deshalb kein durch diese Varianten verursachter Strategiegewinnverlust.** "
        "Die erhebliche Startempfindlichkeit bleibt eine Grenze des historischen Nachweises. Eine ähnliche zukünftige Marktphase garantiert keinen32k-Betrag.", "",
        "## Ertragspriorität korrigiert", "",
        "Die erneut ausdrücklich bestätigte Eigentümervorgabe lautet: **höchster Netto-USDC-Ertrag zuerst, geringerer Drawdown erst danach**. "
        "Mehr DD ist für belegten Mehrertrag zulässig. Die am26.10. zusätzlich verwendete strikte wirtschaftliche DD-Nichtregressionshürde entsprach dieser Rangfolge nicht. "
        "Der ursprüngliche Studienvertrag und seine Ergebnisse bleiben unverändert archiviert; ihre nachträgliche Neusortierung wird offen als **POSTHOC** ausgewiesen.", "",
        "Unter dieser Rangfolge liegt bei den acht bekannten Varianten die24-Stunden-Coinpause nach abgeschlossenen Verlusttrades vorn: "
        "normal **+127,53 USDC**, Stress **+100,42 USDC**, Impact-Annahme **+108,01 USDC** gegenüber der unveränderten Baseline. "
        "Ihre DD-Erhöhungen von0,00024775 /0,00248085 /0,01299035 Prozentpunkten sind kein wirtschaftliches Ausschlusskriterium mehr. "
        "Das sind bereits betrachtete Ergebnisse einer Forschungsvariante, keine neue unabhängige Validierung und keine automatisch übernommene Handelsregel. "
        "Technische Validierung, Ausführungs-/Kostenprüfung, gemeinsame Backtest/Paper/Trial/Live-Integration und gesonderte Aktivierung bleiben Pflicht.", "",
        "## Nachweis und Grenzen", "",
        "Alle zehn nativen Fälle sind vollständig abgeschlossen. Die unabhängige Prüfung rekonstruiert50 Artefakthashes,263.040 Stundenkontowerte und3.217 Fills mit Geldabweichung null. "
        "Die Original32k- und bekannte11k-Kontrolle stimmen außerdem in sämtlichen gespeicherten Metriken, Fills und Trades mit ihren Originalbelegen überein. "
        "Beide schon bekannten Datenfenster sind keine unberührten Out-of-sample-Daten. Historische USDT-Proxykerzen und heutige Exchangefilter beweisen keine damalige USDC-Orderbuchtiefe oder tatsächliche Ausführbarkeit. "
        "Die Legacy-Metadatenangabe `compounding:false` ändert die expliziten tatsächlichen Laufparameter `reinvest_profits:true` und `autonomous_spot:true` nicht.", "",
        "Keine Änderung von Produktquellen, Schlüsselmaterial, laufenden Positionen oder Echtgeldfreigaben, keine Orders und kein Neustart. "
        "Es wurden in dieser Runde keine neuen Fünfjahrespfade erzeugt oder Gewinnerparameter gesucht.", "",
        "- [Alle zehn Ergebnisse als CSV](Comparison.csv) und [vollständige Modellmetriken](Results.json)",
        "- [Abgeleitete öffentliche Vergleichsspezifikation](Comparison-Specification.json)",
        "- [Nachträgliche ertragsorientierte Neusortierung der unveränderten Vorstudie](Posthoc-Profit-Rerank.json)",
        "- [Methodenquellen](Methoden-Code.zip) und [Datei-/Quellenbindung](Public-Evidence.json)", ""]
    report = "\n".join(lines)
    for old_text,new_text in (
        ("aktive15-Profil", "aktive 15-Profil"), ("Versions-Endnummer6", "Versions-Endnummer 6"),
        ("vom26.10.", "vom 26.10."), ("am26.10.", "am 26.10."),
        ("dieselben15", "dieselben 15"), ("je400", "je 400"),
        ("ursprünglichen32k", "ursprünglichen 32k"), ("alten32k", "alten 32k"),
        ("Originales32k", "Originales 32k"), ("Neueres26Oct", "Neueres 26Oct"),
        ("etwa11k", "etwa 11k"), ("Die11.069", "Die 11.069"),
        ("denselben1.092", "denselben 1.092"), ("den400-Stunden", "den 400-Stunden"),
        ("des21k/11k", "des 21k/11k"), ("änderte22.526", "änderte 22.526"),
        ("auf21.793", "auf 21.793"), ("ergab11.004", "ergab 11.004"),
        ("keinen32k", "keinen 32k"), ("die24-Stunden", "die 24-Stunden"),
        ("von0,000", "von 0,000"), ("rekonstruiert50", "rekonstruiert 50"),
        (",263.040", ", 263.040"), ("und3.217", "und 3.217")):
        report = report.replace(old_text,new_text)
    (PUB / "README.md").write_text(report, encoding="utf-8")
    (PUB / ".gitattributes").write_text("# Preserve frozen research bytes.\n* -text whitespace=blank-at-eol,blank-at-eof,space-before-tab,cr-at-eol\n", encoding="utf-8")
    names = sorted(p.name for p in PUB.iterdir() if p.is_file() and p.name != "Public-Evidence.json")
    write(PUB / "Public-Evidence.json", {
        "source_commit": contract["source_commit"], "source_sha256": contract["source_sha256"],
        "original_contract_sha256": sha(OUT / "Contract.json"),
        "original_results_sha256": sha(OUT / "Results.json"),
        "original_interpretation_sha256": sha(OUT / "Interpretation.json"),
        "posthoc_rerank_sha256": sha(OUT / "A09" / "Posthoc-Profit-Rerank.json"),
        "case_complete_sha256": {r["case"]["name"]:r["complete_sha256"] for r in results["cases"]},
        "files_sha256": {name:sha(PUB/name) for name in names},
        "method_sources_sha256": {name:sha(OUT/name) for name in methods},
        "raw_market_and_execution_artifacts_remain_local": True,
        "no_private_account_status_or_credentials_published": True,
        "trading_rules_changed": False, "orders_sent": False,
        "not_a_new_performance_or_live_release": True})
    print(json.dumps({"published_files": len(names)+1, "directory": str(PUB),
                      "old_window_current_end":str(today["ending_equity"]), "net_gain":str(delta)}))


if __name__ == "__main__":
    main()
