"""Post-run attribution of the worst native closing drawdown, not new strategy.

No signals or fills are generated. Cash flows and endpoint holdings attribute
the already-recorded equity change exactly in Decimal accounting.
"""
from __future__ import annotations

import csv
import gzip
import json
from datetime import datetime
from decimal import Decimal as D
from pathlib import Path

import numpy as np

import model


def analyze(result_path):
    result_path = Path(result_path)
    row = json.loads(result_path.read_text())
    complete = json.loads(result_path.with_name("Complete.json").read_text())
    assert complete["complete"] is True
    assert all(model.file_hash(result_path.parent / n) == h
               for n, h in complete["files"].items())
    ctx = model.context()
    directory = model.OUT / "paths" / f"{model.FAMILIES.index(row['family'])}-{row['seed']}"
    assert model.file_hash(directory / "Path.npz") == row["path_file_sha256"]
    with np.load(directory / "Path.npz", allow_pickle=False) as src:
        values = src["values"][model.WARM:]
    with np.load(model.OUT / "Donors.npz", allow_pickle=False) as src:
        symbols = src["symbols"].tolist()
    with gzip.open(result_path.with_name("Equity.csv.gz"), "rt", encoding="utf-8") as stream:
        curve = list(csv.DictReader(stream))
    peak = D(curve[0]["equity"])
    peak_i = worst_peak_i = trough_i = 0
    worst_dd = D(0)
    initial_cash = D(ctx["starting_cash_usdc"])
    minimum = initial_cash
    minimum_i = None
    for i, point in enumerate(curve):
        equity = D(point["equity"])
        if equity < minimum:
            minimum, minimum_i = equity, i
        if equity > peak:
            peak, peak_i = equity, i
        dd = (peak - equity) / peak * 100
        if dd > worst_dd:
            worst_dd, worst_peak_i, trough_i = dd, peak_i, i
    assert abs(worst_dd - D(row["metrics"]["max_drawdown_pct"])) < D("1e-20")
    lookup = {s["signal_id"]: s["symbol"]
              for s in json.loads(result_path.with_name("Signals.json").read_text())}
    fills = json.loads(result_path.with_name("Fills.json").read_text())
    anchor = datetime.fromisoformat(ctx["anchor_utc"])
    owned = {s: D(0) for s in symbols}
    at_peak = owned.copy()
    cashflows = owned.copy()
    period_counts = {s: 0 for s in symbols}
    period_fees = owned.copy()
    cash = D(ctx["starting_cash_usdc"])
    peak_cash = cash
    for fill in fills:
        at = datetime.fromisoformat(fill["fill_time_utc"])
        i = int((at - anchor).total_seconds() / 3600)
        if i > trough_i:
            continue
        symbol = lookup[fill["signal_id"]]
        buy = fill["action"] == "ENTER_LONG"
        quantity = D(fill["base_quantity"])
        flow = -D(fill["quote_value"]) if buy else D(fill["quote_value"]) - D(fill["fee_quote_equivalent"])
        owned[symbol] += quantity if buy else -quantity
        cash += flow
        if i <= worst_peak_i:
            at_peak[symbol] = owned[symbol]
            peak_cash = cash
        else:
            cashflows[symbol] += flow
            period_counts[symbol] += 1
            period_fees[symbol] += D(fill["fee_quote_equivalent"])
    contributions = []
    for j, symbol in enumerate(symbols):
        start_mark = at_peak[symbol] * D(str(values[worst_peak_i, j, model.C]))
        end_mark = owned[symbol] * D(str(values[trough_i, j, model.C]))
        change = end_mark - start_mark + cashflows[symbol]
        contributions.append({"symbol": symbol, "marked_value_at_peak": start_mark,
                              "marked_value_at_trough": end_mark, "period_net_cashflow": cashflows[symbol],
                              "contribution_to_equity_change": change,
                              "period_fill_count": period_counts[symbol], "period_modeled_fees": period_fees[symbol]})
    peak_equity = D(curve[worst_peak_i]["equity"])
    trough_equity = D(curve[trough_i]["equity"])
    attributed_change = sum((x["contribution_to_equity_change"] for x in contributions), D(0))
    assert abs(attributed_change - (trough_equity - peak_equity)) < D("1e-15")
    assert abs(peak_cash - D(curve[worst_peak_i]["cash"])) < D("1e-15")
    assert abs(cash - D(curve[trough_i]["cash"])) < D("1e-15")
    report = {"family": row["family"], "seed": row["seed"], "split": row["split"],
              "variant": row["variant"], "cost": row["cost"],
              "result_sha256": model.file_hash(result_path),
              "path_file_sha256": row["path_file_sha256"],
              "peak_utc": curve[worst_peak_i]["time_utc"],
              "trough_utc": curve[trough_i]["time_utc"],
              "peak_equity": peak_equity, "trough_equity": trough_equity,
              "drawdown_pct": worst_dd, "equity_loss": peak_equity - trough_equity,
              "peak_to_trough_hours": trough_i - worst_peak_i,
              "minimum_equity": minimum,
              "minimum_equity_utc": curve[minimum_i]["time_utc"] if minimum_i is not None else ctx["anchor_utc"],
              "worst_return_vs_start_pct": (minimum / initial_cash - 1) * 100,
              "recovery_needed_pct": (peak_equity / trough_equity - 1) * 100,
              "contributions": sorted(contributions, key=lambda x: x["contribution_to_equity_change"]),
              "attribution_matches_native_equity_change": True,
              "constructed_scenario_not_real_future": True}
    model.write(result_path.with_name("Drawdown-Anatomy.json"), report)
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("result", type=Path)
    print(json.dumps(analyze(parser.parse_args().result), default=str, indent=2))
