"""Frozen synchronous historical-block scenario model; no trading/network APIs.

All conditioning describes known donor markets, never the bot's future features.
Validation generation is gated, even for requested prefixes. Prices are rebased
with one common-per-coin block scale; only declared shocks change it inside a block.
"""
from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import random
from datetime import UTC, datetime, timedelta
from pathlib import Path

import numpy as np

from hixton.backtest.engine import candle_snapshot_sha256
from hixton.backtest.reporting import source_fingerprint
from hixton.domain.models import Candle
from hixton.domain.versions import strategy_definition

OUT = Path(__file__).resolve().parent
LENGTHS = (168, 336, 720)
FIELDS = ("open", "high", "low", "close", "volume", "quote_volume", "trade_count")
O, H, L, C, V, Q, N = range(7)
WARM = 400
FAMILIES = ("empirical_mixed", "risk_on_bias", "winter_then_recovery",
            "noisy_range", "rotation_dispersion", "common_shocks")
SPECS = {
    "lengths": LENGTHS, "length_weights": [1, 1, 1],
    "source_alignment": "same UTC hour and weekday as target block start",
    "risk_on": {"bear": .75, "neutral": 1., "bull": 2.},
    "winter": {"bear": 3., "neutral": 1., "bull": .5},
    "transition": {"bear": 1., "neutral": 2., "bull": 1.},
    "winter_boundaries": [[.4, .6], [.72, .88]],
    "noisy": {"qualified": 4., "other": .5},
    "rotation": {"qualified": 3., "other": 1.},
    "common_shocks": [{"day": 180, "day_jitter": 45, "btc_factor": .65},
                      {"day": 720, "day_jitter": 60, "btc_factor": .8}],
    "shock_beta": "Historical calibration cov(coin,BTC)/var(BTC), clipped .5..2, BTC=1",
    "shock_quote_factor": .2, "shock_quote_hours": 72,
    "clock_and_phase_horizon": "Always full fixed five years, including prefix generation",
    "not_a_future_probability_model": True,
}


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def value_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()


def write(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def context():
    ctx = json.loads((OUT / "Context.json").read_text(encoding="utf-8"))
    assert ctx["source_sha256"] == source_fingerprint(), "Product source changed"
    assert ctx["strategy"] == strategy_definition("v8r").config_payload()
    for kind in ("warmup", "donor", "donor_manifest"):
        assert file_hash(ctx[kind + "_file" if kind != "donor_manifest" else kind]) == ctx[kind + "_file_sha256" if kind != "donor_manifest" else kind + "_sha256"]
    return ctx


def contract_payload():
    ctx = context()
    approval = json.loads((OUT / "Study-Approval.json").read_text())
    assert approval["context_sha256"] == file_hash(OUT / "Context.json")
    return {"source": ctx["source_sha256"], "context_sha256": file_hash(OUT / "Context.json"),
            "approval_sha256": file_hash(OUT / "Study-Approval.json"),
            "prepared_sha256": file_hash(OUT / "Prepared.json"),
            "generator_sha256": file_hash(__file__), "specification": SPECS,
            "families": FAMILIES, "discovery_seeds": ctx["discovery_seeds"],
            "validation_seeds": ctx["validation_seeds"],
            "horizon_start": ctx["anchor_utc"], "horizon_end": ctx["five_year_end_utc"],
            "research_only": True, "not_model_approval": True}


def freeze():
    payload = contract_payload()
    path = OUT / "Model-Contract.json"
    if path.exists():
        assert json.loads(path.read_text()) == json.loads(json.dumps(payload, default=str)), "Model lock differs"
    else:
        write(path, payload)
    return payload


def check_lock():
    assert json.loads((OUT / "Model-Contract.json").read_text()) == json.loads(json.dumps(contract_payload(), default=str))


def _candle(row):
    return Candle(**{**row, "open_time_utc": datetime.fromisoformat(row["open_time_utc"]),
                     "close_time_utc": datetime.fromisoformat(row["close_time_utc"])})


def prepare():
    """Convert public donor data once; do not run the bot or examine its PnL."""
    ctx = context()
    symbols = strategy_definition("v8r").symbols
    assert symbols[0] == "BTCUSDC"
    manifest = json.loads(Path(ctx["donor_manifest"]).read_text())
    with gzip.open(ctx["donor_file"], "rt", encoding="utf-8") as stream:
        raw = json.load(stream)
    arrays, hashes, times = [], {}, None
    proxy = []
    for symbol in symbols:
        rows = raw.pop(symbol)
        candles = [_candle(r) for r in rows]
        assert all(c.ohlc_is_valid and c.closed for c in candles)
        hashes[symbol] = candle_snapshot_sha256(candles)
        assert hashes[symbol] == manifest["data"]["snapshot_sha256_by_symbol"][symbol]
        actual_times = np.asarray([int(c.open_time_utc.timestamp() // 3600) for c in candles], dtype=np.int64)
        assert np.all(np.diff(actual_times) == 1)
        if times is None:
            times = actual_times
        else:
            assert np.array_equal(times, actual_times)
        arrays.append(np.asarray([[getattr(c, f) for f in FIELDS] for c in candles], dtype=np.float64))
        proxy.append(np.asarray(["proxy" in c.source for c in candles], dtype=np.bool_))
    del raw
    values = np.stack(arrays, axis=1)
    with gzip.open(ctx["warmup_file"], "rt", encoding="utf-8") as stream:
        warm_raw = json.load(stream)
    warm_values, warm_times = [], None
    anchor = datetime.fromisoformat(ctx["anchor_utc"])
    for symbol in symbols:
        bars = [_candle(r) for r in warm_raw[symbol]]
        assert len(bars) == WARM and all(c.ohlc_is_valid and c.closed for c in bars)
        ts = np.asarray([int(c.open_time_utc.timestamp() // 3600) for c in bars], dtype=np.int64)
        assert ts[-1] == int(anchor.timestamp() // 3600) - 1 and np.all(np.diff(ts) == 1)
        if warm_times is None:
            warm_times = ts
        else:
            assert np.array_equal(warm_times, ts)
        warm_values.append(np.asarray([[getattr(c, f) for f in FIELDS] for c in bars], dtype=np.float64))
    np.savez_compressed(OUT / "Donors.npz", values=values, times=times,
                        proxy=np.stack(proxy, axis=1), warm=np.stack(warm_values, axis=1),
                        warm_times=warm_times, symbols=np.asarray(symbols))
    returns = np.log(values[1:, :, C] / values[:-1, :, C])
    # Calibration starts at the original report, not its old 400-bar warm-up.
    lo = int(np.searchsorted(times, int(datetime.fromisoformat(manifest["data"]["report_start_utc"]).timestamp() // 3600)))
    r = returns[lo-1:]
    centered = r-r.mean(axis=0)
    beta = (centered * centered[:, [0]]).mean(axis=0) / np.mean(centered[:, 0] ** 2)
    beta = np.clip(beta, .5, 2.)
    beta[0] = 1.
    metadata = {"donor_hashes": hashes, "calibration_lo": lo,
                "calibration_first_utc": datetime.fromtimestamp(int(times[lo]) * 3600, UTC),
                "beta_by_symbol": dict(zip(symbols, beta.tolist(), strict=True)), "pools": {}}
    cp = np.vstack([np.zeros((1, len(symbols))), np.cumsum(returns, axis=0)])
    cp2 = np.concatenate([[0.], np.cumsum(returns[:, 0] ** 2)])
    for length in LENGTHS:
        starts = np.arange(lo, len(values)-length+1, dtype=np.int64)
        # Every UTC hour is available; generation filters exact hour/weekday.
        total = cp[starts+length-1]-cp[starts-1]
        variance = (cp2[starts+length-1]-cp2[starts-1])/length - (total[:, 0]/length)**2
        volatility = np.sqrt(np.maximum(variance, 0.))
        dispersion = np.std(total, axis=1)
        q33, q66 = np.quantile(total[:, 0], [1/3, 2/3])
        regime = np.where(total[:, 0] < q33, -1, np.where(total[:, 0] > q66, 1, 0))
        abs_median, vol_median = np.median(np.abs(total[:, 0])), np.median(volatility)
        noisy = (np.abs(total[:, 0]) <= abs_median) & (volatility >= vol_median)
        rotation = dispersion >= np.quantile(dispersion, 2/3)
        np.savez_compressed(OUT / f"Pool{length}.npz", starts=starts,
                            returns=total[:, 0], volatility=volatility, dispersion=dispersion,
                            regime=regime, noisy=noisy, rotation=rotation)
        metadata["pools"][str(length)] = {"count": len(starts), "btc_return_terciles": [q33, q66],
            "abs_return_median": abs_median, "volatility_median": vol_median,
            "dispersion_q66": np.quantile(dispersion, 2/3)}
    metadata["donor_arrays_sha256"] = file_hash(OUT / "Donors.npz")
    metadata["pool_sha256"] = {str(n): file_hash(OUT / f"Pool{n}.npz") for n in LENGTHS}
    write(OUT / "Prepared.json", metadata)
    print("PREPARED", metadata["donor_arrays_sha256"], flush=True)


def require_seed(ctx, seed):
    if seed in ctx["discovery_seeds"]:
        return "discovery"
    if seed not in ctx["validation_seeds"]:
        raise ValueError("Seed not preregistered")
    selection_path = OUT / "Discovery-Selection.json"
    if not selection_path.exists():
        raise PermissionError("Validation paths are locked until discovery selection")
    selection = json.loads(selection_path.read_text())
    assert selection["context_sha256"] == file_hash(OUT / "Context.json")
    assert selection["model_contract_sha256"] == file_hash(OUT / "Model-Contract.json")
    assert selection["winner"] in ctx["candidate_labels"]
    assert selection["discovery_complete"] is True
    return "validation"


def weights(family, pool, offset, full_hours, phase):
    regime = pool["regime"]
    if family == "risk_on_bias":
        spec = SPECS["risk_on"]
    elif family == "winter_then_recovery":
        fraction = offset/full_hours  # Never requested prefix length.
        spec = SPECS["winter"] if fraction < phase[0] else SPECS["transition"] if fraction < phase[1] else SPECS["risk_on"]
    elif family == "noisy_range":
        return np.where(pool["noisy"], SPECS["noisy"]["qualified"], SPECS["noisy"]["other"])
    elif family == "rotation_dispersion":
        return np.where(pool["rotation"], SPECS["rotation"]["qualified"], SPECS["rotation"]["other"])
    else:
        return np.ones(len(regime))
    return np.where(regime < 0, spec["bear"], np.where(regime > 0, spec["bull"], spec["neutral"]))


def path_arrays(family, seed, hours=None):
    """No bot PnL. Output prefix is invariant to a later requested horizon."""
    check_lock()
    ctx = context()
    split = require_seed(ctx, seed)
    if family not in FAMILIES:
        raise ValueError("Unknown scenario family")
    anchor = datetime.fromisoformat(ctx["anchor_utc"])
    full_hours = int((datetime.fromisoformat(ctx["five_year_end_utc"])-anchor).total_seconds()/3600)
    count = full_hours if hours is None else int(hours)
    assert 0 < count <= full_hours
    prepared = json.loads((OUT / "Prepared.json").read_text())
    assert prepared["donor_arrays_sha256"] == file_hash(OUT / "Donors.npz")
    with np.load(OUT / "Donors.npz", allow_pickle=False) as src:
        donor, times, warm, symbols, proxy = (src[k] for k in ("values", "times", "warm", "symbols", "proxy"))
    pools = {}
    for length in LENGTHS:
        assert prepared["pool_sha256"][str(length)] == file_hash(OUT / f"Pool{length}.npz")
        with np.load(OUT / f"Pool{length}.npz", allow_pickle=False) as src:
            pools[length] = {k: src[k] for k in src.files}
    base_seed = seed + FAMILIES.index(family)*100_000
    rng = random.Random(base_seed)
    phases_rng = random.Random(base_seed+77_000_000)
    phase = [phases_rng.uniform(*SPECS["winter_boundaries"][0]),
             phases_rng.uniform(*SPECS["winter_boundaries"][1])]
    shocks = []
    if family == "common_shocks":
        shock_rng = random.Random(base_seed+88_000_000)
        beta = np.asarray([prepared["beta_by_symbol"][str(s)] for s in symbols])
        for spec in SPECS["common_shocks"]:
            at = (spec["day"]+shock_rng.randint(-spec["day_jitter"], spec["day_jitter"]))*24+shock_rng.randrange(24)
            shocks.append({"hour": at, "factors": np.exp(np.log(spec["btc_factor"])*beta).tolist(),
                           "btc_factor": spec["btc_factor"], "quote_factor": SPECS["shock_quote_factor"],
                           "quote_hours": SPECS["shock_quote_hours"]})
    result = np.empty((WARM+count, len(symbols), len(FIELDS)), dtype=np.float64)
    result[:WARM] = warm
    donor_index = np.empty(count, dtype=np.int32)
    block_index = np.empty(count, dtype=np.int32)
    synthetic_proxy = np.empty((count, len(symbols)), dtype=np.bool_)
    blocks = []
    expected_weights = np.zeros(len(donor), dtype=np.float64)
    offset = 0
    while offset < count:
        length = rng.choice(LENGTHS)  # Always draw nominal full length, also for prefixes.
        pool = pools[length]
        target = anchor+timedelta(hours=offset)
        starts = pool["starts"]
        source_hours = times[starts]
        # Unix epoch was Thursday; Python weekday Monday=0.
        valid = (source_hours % 24 == target.hour) & (((source_hours//24+3) % 7) == target.weekday())
        indices = np.flatnonzero(valid)
        w = weights(family, pool, offset, full_hours, phase)[indices]
        chosen = int(rng.choices(indices.tolist(), weights=w.tolist(), k=1)[0])
        begin = int(starts[chosen])
        take = min(length, count-offset)
        raw = donor[begin:begin+take]
        scales = np.broadcast_to(result[WARM+offset-1, :, C]/donor[begin-1, :, C], (take, len(symbols))).copy()
        q_factor = np.ones(take)
        for shock in shocks:
            shock_offset = shock["hour"]-offset
            if 0 <= shock_offset < take:
                scales[shock_offset:] *= np.asarray(shock["factors"])
            # Shocks outside this block already live in its initial preceding close.
            lo, hi = max(0, shock_offset), min(take, shock_offset+shock["quote_hours"])
            if hi > lo:
                q_factor[lo:hi] *= shock["quote_factor"]
        block = raw.copy()
        block[:, :, :4] *= scales[:, :, None]
        block[:, :, V] = raw[:, :, V]/scales*q_factor[:, None]
        block[:, :, Q] = raw[:, :, Q]*q_factor[:, None]
        result[WARM+offset:WARM+offset+take] = block
        donor_index[offset:offset+take] = np.arange(begin, begin+take)
        block_index[offset:offset+take] = len(blocks)
        synthetic_proxy[offset:offset+take] = proxy[begin:begin+take]
        # Expected conditional pool occupation, independent of selected block/PnL.
        norm = w/w.sum()
        for source_start, probability in zip(starts[indices], norm, strict=True):
            expected_weights[int(source_start):int(source_start)+take] += probability
        blocks.append({"target_hour": offset, "nominal_length": length, "used_length": take,
                       "donor_start": begin, "donor_start_utc": datetime.fromtimestamp(int(times[begin])*3600, UTC),
                       "draw_weight": float(weights(family, pool, offset, full_hours, phase)[chosen])})
        offset += take
    assert np.isfinite(result).all() and (result[:, :, :4] > 0).all()
    assert (result[:, :, H] >= np.maximum(result[:, :, O], result[:, :, C])).all()
    assert (result[:, :, L] <= np.minimum(result[:, :, O], result[:, :, C])).all()
    assert (result[:, :, V:] >= 0).all()
    metadata = {"family": family, "seed": seed, "split": split, "hours": count, "full_hours": full_hours,
                "anchor": ctx["anchor_utc"], "model_contract_sha256": file_hash(OUT / "Model-Contract.json"),
                "phase_fractions_full_horizon": phase, "shocks": shocks, "blocks": blocks,
                "hard_invariants_pass": True, "not_performance_or_plausibility_approval": True}
    if split == "validation":
        metadata["discovery_selection_sha256"] = file_hash(OUT / "Discovery-Selection.json")
    return result, donor_index, block_index, synthetic_proxy, expected_weights, metadata


def save_path(family, seed, hours=None):
    check_lock()
    ctx = context()
    split = require_seed(ctx, seed)
    dest = OUT / "paths" / f"{FAMILIES.index(family)}-{seed}"
    dest.mkdir(parents=True, exist_ok=True)
    if hours is not None:
        dest = dest / f"prefix{hours}"
        dest.mkdir(exist_ok=True)
    path = dest / "Path.npz"
    manifest = dest / "Manifest.json"
    if manifest.exists():
        old = json.loads(manifest.read_text())
        assert old["family"] == family and old["seed"] == seed
        assert old["model_contract_sha256"] == file_hash(OUT / "Model-Contract.json")
        assert old["path_file_sha256"] == file_hash(path)
        if split == "validation":
            assert old["discovery_selection_sha256"] == file_hash(OUT / "Discovery-Selection.json")
        return dest
    values, donor_index, block_index, proxy, expected, meta = path_arrays(family, seed, hours)
    temporary = dest / "Path.tmp.npz"
    np.savez_compressed(temporary, values=values, donor_index=donor_index,
                        block_index=block_index, proxy=proxy, expected_weights=expected)
    temporary.replace(path)
    meta["path_file_sha256"] = file_hash(path)
    write(dest / "Manifest.json", meta)
    print("PATH_SAVED", dest, flush=True)
    return dest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("prepare", "freeze", "generate"))
    parser.add_argument("--family", choices=FAMILIES, default=FAMILIES[0])
    parser.add_argument("--seed", type=int, default=251001)
    parser.add_argument("--hours", type=int)
    args = parser.parse_args()
    if args.mode == "prepare":
        prepare()
    elif args.mode == "freeze":
        freeze()
    else:
        save_path(args.family, args.seed, args.hours)


if __name__ == "__main__":
    main()
