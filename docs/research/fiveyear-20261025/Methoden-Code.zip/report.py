"""Descriptive final study report. Selection remains frozen in analysis.py."""
from __future__ import annotations

import csv
import gzip
import json
from collections import defaultdict
from datetime import datetime, timedelta
from decimal import Decimal as D
from pathlib import Path
from statistics import median

import analysis

OUT = Path(__file__).resolve().parent
LABELS = {
    "empirical_mixed": "Historische Marktphasen gemischt",
    "risk_on_bias": "Extremer Bullenmarkt (positiv gewichtete Blöcke)",
    "winter_then_recovery": "Langer Bärenmarkt, dann Erholung",
    "noisy_range": "Unruhige Blöcke mit geringem BTC-Trend",
    "rotation_dispersion": "Wechselnde starke und schwache Coins",
    "common_shocks": "Gemeinsame Crashs mit Volumeneinbruch",
}
VARIANTS = {"current": "Aktueller Bot", "gapfillers_off": "Ohne Zwischenfüller",
            "exposure85": "85 % Kapitalfreigabe", "one_per_symbol": "Core-Slots ohne doppelte Coinbelegung"}


def de(value, places=2):
    return f"{float(value):,.{places}f}".replace(",", "_").replace(".", ",").replace("_", ".")


def aggregate(rows, initial):
    ends = [D(r["metrics"]["ending_equity"]) for r in rows]
    dds = [D(r["metrics"]["max_drawdown_pct"]) for r in rows]
    return {"constructed_paths": len(rows), "end_min": min(ends), "end_median": median(ends),
            "end_max": max(ends), "worst_close_dd_pct": max(dds),
            "median_close_dd_pct": median(dds),
            "ending_below_start_paths": sum(x < initial for x in ends),
            "orders": sum(r["liquidity"]["count"] for r in rows),
            "orders_over_1pct_prior_hour_volume": sum(r["liquidity"]["over_1pct"] for r in rows),
            "orders_over_5pct_prior_hour_volume": sum(r["liquidity"]["over_5pct"] for r in rows),
            "orders_with_unknown_prior_volume": sum(r["liquidity"]["unknown_volume"] for r in rows),
            "orders_with_historical_quote_proxy": sum(r["liquidity"]["proxy_count"] for r in rows),
            "largest_prior_hour_volume_ratio": max(D(r["liquidity"]["max_ratio"] or 0) for r in rows),
            "not_future_probabilities": True}


def chart(context, baseline):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    fig, axes = plt.subplots(3, 2, figsize=(13, 11), constrained_layout=True)
    initial = float(context["starting_cash_usdc"])
    seed_labels = {seed: f"{split[0].upper()}{i+1}" for split in ("discovery", "validation")
                   for i, seed in enumerate(context[split + "_seeds"])}
    colors = {seed: c for seed, c in zip(seed_labels, ("#006da9", "#007d67", "#9757a3", "#d17812"))}
    for ax, family in zip(axes.flat, context["families"]):
        for row in baseline:
            if row["family"] != family or row["cost"] != "current":
                continue
            with gzip.open(OUT / row["result_path"].replace("Result.json", "Equity.csv.gz"),
                           "rt", encoding="utf-8") as stream:
                points = list(csv.DictReader(stream))
            picked = points[::24]
            if picked[-1] != points[-1]:
                picked.append(points[-1])
            dates = [datetime.fromisoformat(p["time_utc"]) for p in picked]
            values = [float(p["equity"]) for p in picked]
            ax.plot(dates, values, lw=1, alpha=.85, color=colors[row["seed"]],
                    label=seed_labels[row["seed"]])
        ax.axhline(initial, color="#687583", lw=.7, linestyle="--")
        ax.set_title(LABELS[family], fontsize=10, loc="left")
        ax.set_yscale("log")
        ax.yaxis.set_major_formatter(ticker.FuncFormatter(lambda x, pos: f"{x:,.0f}".replace(",", ".")))
        ax.grid(alpha=.18, which="both")
        ax.set_ylabel("USDC · logarithmische Skala", fontsize=8)
        ax.tick_params(labelsize=8)
        ax.legend(ncol=4, fontsize=7, frameon=False)
    fig.suptitle("Aktueller Hixton · fünf Jahre in konstruierten Marktverläufen", fontsize=16, weight="bold")
    fig.supxlabel("2026–2031 sind erfundene Szenariozeiten · keine Vorhersage · vier Pfade je Familie\n"
                  "Start 1.085,77 USDC · normale Modellkosten · täglich dargestellte Punkte\n"
                  "Tabellen-DD aus stündlicher Kurve · D: Auswahl, V: Prüfung", fontsize=8)
    fig.savefig(OUT / "Szenarien.png", dpi=155)
    plt.close(fig)


def price_chart(context):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    import numpy as np
    anchor = datetime.fromisoformat(context["anchor_utc"])
    hours = int((datetime.fromisoformat(context["five_year_end_utc"]) - anchor).total_seconds() / 3600)
    with np.load(OUT / "Donors.npz", allow_pickle=False) as src:
        symbols = src["symbols"].tolist()
    fig, axes = plt.subplots(3, 2, figsize=(13, 11), constrained_layout=True)
    for number, (ax, family) in enumerate(zip(axes.flat, context["families"])):
        directory = OUT / "paths" / f"{number}-{context['discovery_seeds'][0]}"
        with np.load(directory / "Path.npz", allow_pickle=False) as src:
            values = src["values"]
        warmup = len(values) - hours
        assert warmup == 400
        indices = np.unique(np.r_[np.arange(0, hours, 24), hours-1])
        dates = [anchor + timedelta(hours=int(i)+1) for i in indices]
        marked = values[warmup+indices, :, 3] / values[warmup-1, :, 3] * 100
        for j, symbol in enumerate(symbols):
            if symbol not in ("BTCUSDC", "ETHUSDC"):
                ax.plot(dates, marked[:, j], color="#8c99a5", lw=.65, alpha=.5)
        for symbol, color in (("BTCUSDC", "#006da9"), ("ETHUSDC", "#c06b00")):
            ax.plot(dates, marked[:, symbols.index(symbol)], color=color, lw=1.3, label=symbol.removesuffix("USDC"))
        ax.axhline(100, color="#64717d", lw=.7, linestyle="--")
        ax.set_yscale("log")
        ax.set_title(LABELS[family], fontsize=10, loc="left")
        ax.set_ylabel("Kursindex · Start = 100 · logarithmisch", fontsize=8)
        ax.grid(alpha=.18, which="both")
        ax.tick_params(labelsize=8)
        ax.legend(fontsize=7, frameon=False)
    fig.suptitle("Konstruierte Marktpreise · Beispielpfad D1 jeder Familie", fontsize=16, weight="bold")
    fig.supxlabel("Vorab festgelegter erster Auswahlpfad, keine Auswahl nach Gewinn · grau: weitere 13 Märkte\n"
                  "Täglich dargestellte Punkte · synthetische Szenarien 2026–2031, einschließlich extremer Preisniveaus", fontsize=8)
    fig.savefig(OUT / "Marktpfade.png", dpi=155)
    plt.close(fig)


def main():
    selection = analysis.load(OUT / "Discovery-Selection.json")
    validation = analysis.load(OUT / "Validation-Summary.json")
    assert validation["discovery_selection_sha256"] == analysis.digest(OUT / "Discovery-Selection.json")
    context, discovery = analysis.results("discovery")
    _, valid_rows = analysis.results("validation")
    assert selection["selection_script_sha256"] == analysis.digest(analysis.__file__)
    assert selection["context_sha256"] == analysis.digest(OUT / "Context.json")
    assert selection["model_contract_sha256"] == analysis.digest(OUT / "Model-Contract.json")
    assert selection["study_approval_sha256"] == analysis.digest(OUT / "Study-Approval.json")
    assert selection["source_sha256"] == context["source_sha256"]
    assert selection["discovery_result_sha256"] == {r["result_path"]: r["result_sha256"] for r in discovery.values()}
    assert selection["discovery_complete_sha256"] == {r["complete_path"]: r["complete_sha256"] for r in discovery.values()}
    assert validation["validation_result_sha256"] == {r["result_path"]: r["result_sha256"] for r in valid_rows.values()}
    assert validation["validation_complete_sha256"] == {r["complete_path"]: r["complete_sha256"] for r in valid_rows.values()}
    assert all(r["discovery_selection_sha256"] == analysis.digest(OUT / "Discovery-Selection.json") for r in valid_rows.values())
    assert set(discovery) == analysis.expected(context, "discovery", context["candidate_labels"])
    assert set(valid_rows) == analysis.expected(context, "validation", list(dict.fromkeys(["current", selection["winner"]])))
    assert all(analysis.technically_valid(r) for r in [*discovery.values(), *valid_rows.values()])
    rows = [*discovery.values(), *valid_rows.values()]
    baseline = [r for r in rows if r["variant"] == "current"]
    assert len(baseline) == 52
    initial = D(context["starting_cash_usdc"])
    families = {}
    for family in context["families"]:
        families[family] = {cost: aggregate([r for r in baseline if r["family"] == family and r["cost"] == cost], initial)
                            for cost in (("current", "stress", "tail50") if family == "common_shocks" else ("current", "stress"))}
        diagnostics = [analysis.load(OUT / "paths" / f"{context['families'].index(family)}-{seed}" / "Diagnostics.json")
                       for seed in [*context["discovery_seeds"], *context["validation_seeds"]]]
        families[family]["macro_context"] = {
            "flagged_paths": sum(d["macro_extreme_context_flag"] for d in diagnostics),
            "total_paths": len(diagnostics),
            "btc_end_multiples": [d["end_price_multiple_by_coin"]["BTCUSDC"] for d in diagnostics],
            "eth_end_multiples": [d["end_price_multiple_by_coin"]["ETHUSDC"] for d in diagnostics],
            "context_heuristic_not_probability_or_rejection": True}
    normal = [r for r in baseline if r["cost"] == "current"]
    stress = [r for r in baseline if r["cost"] == "stress"]
    no_macro_flag = []
    for row in normal:
        directory = OUT / "paths" / f"{context['families'].index(row['family'])}-{row['seed']}"
        diagnostic = analysis.load(directory / "Diagnostics.json")
        assert diagnostic["path_file_sha256"] == row["path_file_sha256"]
        if not diagnostic["macro_extreme_context_flag"]:
            no_macro_flag.append(row)
    anatomies = []
    for row in normal:
        path = OUT / row["result_path"]
        anatomy = analysis.load(path.with_name("Drawdown-Anatomy.json"))
        assert anatomy["result_sha256"] == row["result_sha256"]
        assert abs(D(anatomy["drawdown_pct"]) - D(row["metrics"]["max_drawdown_pct"])) < D("1e-20")
        assert anatomy["attribution_matches_native_equity_change"] is True
        anatomies.append(anatomy)
    worst = min(normal, key=lambda r: D(r["metrics"]["ending_equity"]))
    worst_dd = max(normal, key=lambda r: D(r["metrics"]["max_drawdown_pct"]))
    validation_comparison = {
        cost: {v: aggregate([r for r in valid_rows.values() if r["variant"] == v and r["cost"] == cost], initial)
               for v in dict.fromkeys(["current", selection["winner"]])}
        for cost in ("current", "stress", "tail50")}
    discovery_advantages = [D(discovery[f, seed, selection["winner"], "current"]["metrics"]["net_pnl"])
                            - D(discovery[f, seed, "current", "current"]["metrics"]["net_pnl"])
                            for f in context["families"] for seed in context["discovery_seeds"]]
    discovery_paired = {"better": sum(x > 0 for x in discovery_advantages),
                        "worse": sum(x < 0 for x in discovery_advantages),
                        "equal": sum(x == 0 for x in discovery_advantages),
                        "median_net_advantage": median(discovery_advantages),
                        "descriptive_only_not_a_changed_selection_rule": True}
    summary = {"source_commit": context["source_commit"], "source_sha256": context["source_sha256"],
               "start_usdc": initial, "cases": len(rows), "discovery_cases": len(discovery),
               "validation_cases": len(valid_rows), "families": families,
               "baseline_normal": aggregate(normal, initial), "baseline_stress": aggregate(stress, initial),
               "baseline_normal_without_macro_flag_descriptive_only": aggregate(no_macro_flag, initial),
               "worst_normal_end_result": worst["result_path"], "worst_normal_dd_result": worst_dd["result_path"],
               "discovery_winner": selection["winner"], "validation_decision": validation["decision"],
               "validation_comparison": validation_comparison,
               "discovery_selected_paired_normal": discovery_paired,
               "baseline_normal_dd_exceeds_30pct_paths": sum(D(r["metrics"]["max_drawdown_pct"]) > 30 for r in normal),
               "minimum_equity_across_normal_paths": min(D(a["minimum_equity"]) for a in anatomies),
               "worst_initial_capital_return_pct": min(D(a["worst_return_vs_start_pct"]) for a in anatomies),
               "selection_sha256": analysis.digest(OUT / "Discovery-Selection.json"),
               "validation_sha256": analysis.digest(OUT / "Validation-Summary.json"),
               "all_native_technical_checks_pass": True, "product_changed": False,
               "synthetic_model_not_forecast_or_unseen_real_data": True}
    analysis.write(OUT / "Summary.json", summary)
    with (OUT / "Alle-Ergebnisse.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["phase", "szenario", "seed", "variante", "kosten", "start_usdc", "end_usdc", "netto_pnl",
                         "max_close_dd_pct", "orders", "orders_ueber_5_prozent_vorheriges_stundenvolumen", "ergebnis_datei"])
        for row in rows:
            m = row["metrics"]
            writer.writerow([row["split"], row["family"], row["seed"], row["variant"], row["cost"], initial,
                             m["ending_equity"], m["net_pnl"], m["max_drawdown_pct"], row["liquidity"]["count"],
                             row["liquidity"]["over_5pct"], row["result_path"]])
    with (OUT / "Coin-Beitraege.csv").open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.writer(stream, delimiter=";")
        writer.writerow(["phase", "szenario", "seed", "coin", "pnl_abgeschlossene_exitanteile",
                         "exitanteile", "modellgebuehren", "umsatz_usdc", "kein_eigenes_startkapital_pro_coin"])
        for row in normal:
            for symbol, contribution in row["per_coin"].items():
                writer.writerow([row["split"], row["family"], row["seed"], symbol, contribution["realized_pnl"],
                                 contribution["exit_legs"], contribution["fees"], contribution["turnover"], True])
    lines = ["# Hixton: fünf Jahre in verschiedenen Marktbedingungen", "",
             f"Referenz: aktueller Bot `{context['source_commit'][:10]}`, Start **{de(initial)} USDC**, Gewinne wiederangelegt. Drei ausdrücklich getrennte Researchvarianten werden dagegen verglichen.",
             "Die native Berechnung verwendet die aktuellen Kapital-, ATR-, Tranchenteilungs- und Diversifikationsregeln einschließlich der 32.000-USDC-Stufe; keine vereinfachte Ersatzstrategie.",
             "Start ohne offene Modellpositionen mit dem eingefrorenen freien Spot-USDC-Guthaben. Bestehende fremde Coinbestände gehören nicht zum simulierten Botkapital.",
             f"{len(rows)} vollständig geprüfte native Portfolioläufe: {len(discovery)} Auswahl und {len(valid_rows)} separate Modellprüfung.",
             "Gemeinsames 15-Markt-Portfolio gemäß den aktuellen Entry-Freigaben: zehn Core-Märkte plus aktive Zwischenfüller AAVE/BCH/NEAR. SUI/UNI bleiben Research-only. Es gibt kein vervielfachtes Startkapital je Währung.", "",
             "## Ergebnis des aktuellen Bots", "",
             "Vier konstruierte Pfade je Familie. Spannweiten und Verlustfallzahlen beschreiben diese Pfade, keine Zukunftswahrscheinlichkeiten.", "",
             "| Marktverlauf | End-USDC: kleinster–größter Wert | Median End-USDC | Schlimmster Schlusskurs-DD | Median bei höheren Kosten | Makroextreme Pfade |",
             "|---|---:|---:|---:|---:|---:|"]
    for family, costs in families.items():
        a, b = costs["current"], costs["stress"]
        lines.append(f"| {LABELS[family]} | {de(a['end_min'])}–{de(a['end_max'])} | {de(a['end_median'])} | {de(a['worst_close_dd_pct'])} % | {de(b['end_median'])} | {costs['macro_context']['flagged_paths']}/4 |")
    lines += ["", "Die Szenarionamen beschreiben die Auswahl historischer Blöcke; sie erzwingen keinen bestimmten Fünfjahres-Endkurs. Zur Einordnung der Modellpfade:", "",
              "| Blockfamilie | BTC: Endkurs / Startkurs | ETH: Endkurs / Startkurs |",
              "|---|---:|---:|"]
    for family, costs in families.items():
        macro = costs["macro_context"]
        lines.append(f"| {LABELS[family]} | {de(min(macro['btc_end_multiples']))}–{de(max(macro['btc_end_multiples']))}× | {de(min(macro['eth_end_multiples']))}–{de(max(macro['eth_end_multiples']))}× |")
    lines += ["", "![Alle normalen Modellpfade](Szenarien.png)", "",
              f"In **{summary['baseline_normal_dd_exceeds_30pct_paths']} von 24** konstruierten Normal-Kosten-Pfaden überschreitet der aktuelle Bot 30 % Schlusskurs-DD. Das ist keine Eintrittswahrscheinlichkeit; die aktive Strategie besitzt hier keine belastbar nachgewiesene 30-%-Verlustbegrenzung.",
              f"Auch unter den {len(no_macro_flag)} Pfaden ohne Makro-Extremhinweis beträgt der schlimmste Schlusskurs-DD **{de(summary['baseline_normal_without_macro_flag_descriptive_only']['worst_close_dd_pct'])} %**. Diese rein beschreibende Untergruppe ändert weder die eingefrorene Auswahl noch die Prüfkriterien und stellt keine Zertifizierung realistischer Zukunftskurse dar.",
              f"Niedrigster modellierter Kontostand über diese Pfade: **{de(summary['minimum_equity_across_normal_paths'])} USDC**, entsprechend **{de(summary['worst_initial_capital_return_pct'])} %** gegenüber dem Startbudget. Diese Zahl ist vom Rückgang ab einem späteren Kontohöchststand zu unterscheiden.",
              "Der Endwert allein zeigt weder den zwischenzeitlichen Verlust noch die Erholungsdauer. Bereits ein technisch korrekt abgewickelter Lauf kann wirtschaftlich untragbar sein.", "",
              "## Vorab festgelegte Varianten", "",
              "Auswahl nach höchstem mittleren Nettogewinn (Median), danach niedrigerem DD. Normales und erhöhtes Kostenmedian dürfen gegenüber dem aktuellen Bot nicht fallen.", "",
              "| Variante | Median Netto-Gewinn | Median DD | Median Netto bei Stresskosten | Auswahlfähig |",
              "|---|---:|---:|---:|---|"]
    for variant in context["candidate_labels"]:
        s = selection["summary"][variant]
        lines.append(f"| {VARIANTS[variant]} | {de(s['normal_median_net'])} | {de(s['normal_median_close_dd'])} % | {de(s['stress_median_net'])} | {'ja' if s['eligible'] else 'nein'} |")
    lines += ["", f"Vor Betrachtung der Prüfszenarien eingefroren: **{VARIANTS[selection['winner']]}**.",
              f"Gepaart auf denselben zwölf Auswahlpfaden: {discovery_paired['better']} besser, {discovery_paired['worse']} schlechter, {discovery_paired['equal']} gleich; Median des direkten Netto-Unterschieds **{de(discovery_paired['median_net_advantage'])} USDC**. Die Differenz zweier unverbundener Mediane ist etwas anderes als der Median gepaarter Unterschiede; die ursprüngliche Auswahlregel wurde nicht nachträglich geändert.",
              f"Separate Modellprüfung: **{validation['decision']}**.",
              f"Gepaarter Median des Netto-Vorteils: normal **{de(validation['normal_paired_median_net_advantage'])} USDC**, mit höheren Kosten **{de(validation['stress_paired_median_net_advantage'])} USDC**.",
              f"Normale Prüffälle: {validation['normal_strictly_better_paths']} besser, {validation['normal_strictly_worse_paths']} schlechter, {validation['normal_equal_paths']} gleich.",
              "Auch ein bestandener Modellvergleich erlaubt keine automatische Produkt- oder Liveänderung.", "",
              "| Getrennte Prüffälle | Pfade | Median End-USDC aktuell | Median End-USDC Variante | Schlimmster DD aktuell | Schlimmster DD Variante |",
              "|---|---:|---:|---:|---:|---:|"]
    for cost, values in validation_comparison.items():
        a, b = values["current"], values[selection["winner"]]
        label = {"current": "Normale Kosten", "stress": "Höhere Kosten", "tail50": "Stärkster Kostenstress, nur Crashfamilie"}[cost]
        lines.append(f"| {label} | {a['constructed_paths']} | {de(a['end_median'])} | {de(b['end_median'])} | {de(a['worst_close_dd_pct'])} % | {de(b['worst_close_dd_pct'])} % |")
    tail = families["common_shocks"]["tail50"]
    lines += ["", f"Aktueller Bot im stärksten Crashkostenstress über alle vier Crashpfade: Endwerte **{de(tail['end_min'])}–{de(tail['end_max'])} USDC**, schlimmster Schlusskurs-DD **{de(tail['worst_close_dd_pct'])} %**.", "",
              "## Was die Zahlen begrenzt", "",
              "- Nominales USDC, kein Eurobetrag. Keine Prognose und keine Wahrscheinlichkeit, einen bestimmten Endbetrag zu erreichen.",
              "- Endkapital bedeutet Cash plus zum letzten Kurs bewertete offene Bestände einschließlich Restmengen. Es wird am Studienende kein zusätzlicher Verkauf erzwungen; noch nicht angefallene Ausstiegskosten offener Bestände sind nicht als bereits bezahlt dargestellt.",
              "- Gemeinsame historische 7-/14-/30-Tage-Blöcke erhalten Abhängigkeiten zwischen den 15 Coins. Neue Zufallszahlen liefern neue Kombinationen derselben bekannten Daten, keine wirklich ungesehene Marktgeschichte.",
              "- Positiv gewichtete Blöcke können über fünf Jahre wirtschaftlich extreme Kursniveaus erzeugen. Die Spalte Makroextreme kennzeichnet BTC außerhalb 0,1–10× oder ETH außerhalb 0,05–20× des Startkurses. Das ist ein vorher festgelegter Kontextindikator, keine Wahrscheinlichkeitsgrenze. Solche Pfade bleiben vollständig erhalten, gelten als Sensitivitäts-/Extremtests und belegen keine realistische Gewinnperspektive.",
              "- Die sechs Familien sind vorab gleich viele Vergleichsfälle, keine geschätzte Häufigkeitsmischung zukünftiger Marktregime. Ihr gemeinsamer Median dient ausschließlich diesem eingefrorenen Modellvergleich.",
              "- Die gemeinsame Datenbasis enthält 2022 nicht. Heutige Coins, Filter und Überlebensauswahl bilden frühere Pleiten oder künftige Delistings nicht vollständig ab. Die externe BTC/ETH-Fünfjahreskalibrierung zeigt deutlich stärkere historische Bärenmärkte.",
              "- Kein Orderbuch, keine Marktbeeinflussung, keine echten Teilausführungen. Teilnahme am vorherigen Stundenvolumen ist ein Warnindikator, kein Ausführbarkeitsbeweis.",
              f"- In den 24 normalen Baselinepfaden liegen {summary['baseline_normal']['orders_over_5pct_prior_hour_volume']} von {summary['baseline_normal']['orders']} modellierten Orders über 5 % des vorherigen Stundenvolumens. Größtes Verhältnis: {de(summary['baseline_normal']['largest_prior_hour_volume_ratio']*100)} %.",
              "- Kosten pro Kauf und Verkauf: normal 10 bp Gebühr + 2 bp Spread + 3 bp Slippage; Stress 10 + 10 + 20 bp. Im Crash zusätzlich 10 + 15 + 25 bp. Kein angenommener BNB-Rabatt.",
              "- Crashfamilie: zusätzliche BTC-Sprünge von −35 % und −20 %, für andere Coins über historische Betas von 0,5–2 skaliert, sowie jeweils 80 % weniger Quotevolumen für 72 Stunden. Absichtlich widrige Stressbedingungen, keine Behauptung ihrer Eintrittshäufigkeit.",
              "- Der native DD misst stündliche Schlussmarkierungen. Die Grafik zeigt täglich ausgedünnte Punkte, die Tabellen verwenden die vollständigen Stundenkurven. Intrastündliche Verluste können größer sein. Zusätzliche OHLC-Stressmarkierungen sind konstruierte Hüllen, keine beobachteten Intrastundenkurven oder garantierten Verlustgrenzen.",
              "- Keine Strom-, Internet-, Börsen-, Gegenpartei- oder USDC-Entkopplungsausfälle modelliert. Ein lokal ausgeschalteter Bot kann keine Strategieausstiege ausführen.", "",
              "## Nachprüfbarkeit", "",
              "`Context.json`, `Study-Approval.json` und `Model-Contract.json` wurden vor den neuen Ergebnissen eingefroren. Auswahl und Prüffälle sind getrennt; jeder Lauf speichert Fills, Signale, Equity und Prüfsummen. Kein schlechter Pfad wurde ersetzt.",
              "`Discovery-Selection.json` bindet alle Auswahlresultate; `Validation-Summary.json` bindet die späteren Prüffälle. `Alle-Ergebnisse.csv` enthält sämtliche Resultate.",
              "`Coin-Beitraege.csv` zeigt die 15 Coinbeiträge je normalem Baselinepfad im gemeinsamen Portfolio. Der PnL dort bezieht sich auf geschlossene Exitanteile; noch offene Positionen und Restbestände sind darin nicht als vollständig realisierter Gewinn enthalten. Es sind keine 15 separaten Konten mit jeweils dem gesamten Startkapital.",
              "Die native Buchhaltung wurde stündlich exakt nachgerechnet; keine negativen Cash-/Bestandswerte, keine Ausführung vor einem abgeschlossenen Signal, DD unabhängig nachgerechnet. Die Zukunftsänderungsprobe bewahrte die früheren Signale und Fills.",
              "`Marktpfade.png` zeigt den vorab festgelegten ersten Auswahlpfad jeder Familie für alle 15 Märkte; BTC/ETH sind hervorgehoben. Keine Auswahl eines besonders erfolgreichen Beispiels.",
              "Methodischer Bezug: [Politis & Romano (1994)](https://doi.org/10.1080/01621459.1994.10476870). Diese bedingte Blocksimulation beansprucht keine Zukunfts-Konfidenzintervalle.", ""]
    (OUT / "Bericht.md").write_text("\n".join(lines), encoding="utf-8")
    chart(context, baseline)
    price_chart(context)
    print(json.dumps(summary, default=str, indent=2))


if __name__ == "__main__":
    main()
