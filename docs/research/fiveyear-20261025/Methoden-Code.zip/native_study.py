"""Native ledger runner; durable per-case completion, no product mutations."""
from __future__ import annotations

import argparse
import csv
import ctypes
import gzip
import json
import os
import time
from collections import Counter, defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import asdict, replace
from datetime import datetime, timedelta
from decimal import Decimal as D

import numpy as np

import diagnostics
import model
from hixton.backtest.models import CURRENT_COSTS, STRESS_COSTS, CostModel, ExecutionRules
from hixton.backtest.portfolio import run_shared_portfolio_backtest
from hixton.backtest.reporting import source_fingerprint
from hixton.domain.allocation import ONE_PER_SYMBOL
from hixton.domain.market_rules import FILTER_DECIMALS
from hixton.domain.models import Candle, SignalAction
from hixton.domain.versions import strategy_definition

OUT=model.OUT
TAIL50=CostModel("tail50",D(10),D(15),D(25))
COSTS={"current":CURRENT_COSTS,"stress":STRESS_COSTS,"tail50":TAIL50}


def low_priority_and_peak_mb():
    if os.name != "nt":
        return None
    from ctypes import wintypes
    class Memory(ctypes.Structure):
        _fields_=[("cb",wintypes.DWORD),("faults",wintypes.DWORD),
                  *[(name,ctypes.c_size_t) for name in ("peak","working","pagedpeak","paged",
                     "nonpagedpeak","nonpaged","pagefile","pagefilepeak")]]
    kernel=ctypes.WinDLL("kernel32")
    kernel.GetCurrentProcess.restype=wintypes.HANDLE
    handle=kernel.GetCurrentProcess()
    kernel.SetPriorityClass.argtypes=[wintypes.HANDLE,wintypes.DWORD]
    kernel.SetPriorityClass(handle,0x4000)  # Only this research process, BELOW_NORMAL.
    memory=Memory();memory.cb=ctypes.sizeof(memory)
    psapi=ctypes.WinDLL("psapi")
    psapi.GetProcessMemoryInfo.argtypes=[wintypes.HANDLE,ctypes.c_void_p,wintypes.DWORD]
    return float(memory.peak/1024**2) if psapi.GetProcessMemoryInfo(handle,ctypes.byref(memory),memory.cb) else None


def rules_from(ctx):
    return {s:ExecutionRules(**{k:D(v) if k in FILTER_DECIMALS else v for k,v in r.items()})
            for s,r in ctx["execution_rules"].items()}


def candidate(label):
    base=strategy_definition("v8r")
    if label=="current":
        return base
    changes={"gapfillers_off":{"active_shared_satellites":()},
             "exposure85":{"capital_exposure_fraction":".85"},
             "one_per_symbol":{"slot_allocation":ONE_PER_SYMBOL}}
    return replace(base,version=base.version+"-RESEARCH-"+label,
                   paper_approved=False,**changes[label])


def candles_from(values,ctx):
    symbols=strategy_definition("v8r").symbols
    anchor=datetime.fromisoformat(ctx["anchor_utc"])
    data={s:[] for s in symbols}
    for i,row in enumerate(values):
        at=anchor+timedelta(hours=i-model.WARM);close_at=at+timedelta(hours=1,milliseconds=-1)
        for j,symbol in enumerate(symbols):
            op,hi,lo,cl,volume,quote,trades=row[j]
            data[symbol].append(Candle(symbol,at,close_at,float(op),float(hi),float(lo),float(cl),
                float(volume),float(quote),int(trades),True,
                "SYNTHETIC_JOINT_BLOCK_BOOTSTRAP_NOT_REAL_FUTURE"))
    return data


def audit_ledger(result,data,proxy):
    signals={s.signal_id:s for s in result.signals}
    groups=defaultdict(list)
    for fill in result.fills:
        signal=signals[fill.signal_id]
        assert signal.candle_close_time_utc<fill.fill_time_utc
        groups[fill.fill_time_utc].append(fill)
    cash=result.starting_cash;owned=dict.fromkeys(data,D(0));peak=cash;maxdd=D(0)
    liquidity=[];percoin={s:{"realized_pnl":D(0),"exit_legs":0,"fees":D(0),"turnover":D(0)} for s in data}
    start=result.report_start_utc
    for i,point in enumerate(result.equity_curve):
        at=start+timedelta(hours=i)
        for fill in groups[at]:
            symbol=signals[fill.signal_id].symbol
            if fill.action==SignalAction.ENTER_LONG:
                cash-=fill.quote_value;owned[symbol]+=fill.base_quantity
            else:
                cash+=fill.quote_value-fill.fee_quote_equivalent;owned[symbol]-=fill.base_quantity
            previous=data[symbol][model.WARM+i-1]
            q=D(str(previous.quote_volume))
            ratio=fill.quote_value/q if q>0 else None
            liquidity.append({"time":at,"symbol":symbol,"side":fill.action,
                "notional":fill.quote_value,"known_previous_closed_quote_volume":q,
                "participation_ratio":ratio,"zero_quote_volume":q==0,
                "source_is_historical_quote_proxy":bool(proxy[i-1,list(data).index(symbol)]) if i else False})
            percoin[symbol]["fees"]+=fill.fee_quote_equivalent
            percoin[symbol]["turnover"]+=fill.quote_value
        assert cash>=0 and min(owned.values())>=0
        equity=cash+sum((quantity*D(str(data[s][model.WARM+i].close)) for s,quantity in owned.items()),D(0))
        assert abs(equity-point.equity)<D("1e-15")
        assert abs(cash-point.cash)<D("1e-15")
        peak=max(peak,equity);maxdd=max(maxdd,(peak-equity)/peak*100)
    # Product drawdown starts at first marked reporting equity; no artificial pre-bar DD.
    marked_peak=result.equity_curve[0].equity;marked_dd=D(0)
    for point in result.equity_curve:
        marked_peak=max(marked_peak,point.equity)
        marked_dd=max(marked_dd,(marked_peak-point.equity)/marked_peak*100)
    assert abs(marked_dd-result.metrics.max_drawdown_pct)<D("1e-20")
    for trade in result.trades:
        percoin[trade.symbol]["realized_pnl"]+=trade.realized_pnl
        percoin[trade.symbol]["exit_legs"]+=1
    summary={"count":len(liquidity),"over_1pct":sum(x["participation_ratio"] is not None and x["participation_ratio"]>D(".01") for x in liquidity),
             "over_5pct":sum(x["participation_ratio"] is not None and x["participation_ratio"]>D(".05") for x in liquidity),
             "max_ratio":max((x["participation_ratio"] for x in liquidity if x["participation_ratio"] is not None),default=None),
             "unknown_volume":sum(x["zero_quote_volume"] for x in liquidity),
             "proxy_count":sum(x["source_is_historical_quote_proxy"] for x in liquidity),
             "not_actual_orderbook_fillability":True}
    return {"cash_equity":True,"nonnegative":True,"causality":True,"dd_recomputed":True},summary,liquidity,percoin


def authorize_request(approval, *, operation, ctx, family=None, seed=None,
                      variants=None, cost_names=None):
    """Fail closed before generating paths or launching workers outside signed scope."""
    scope=approval.get("scope")
    assert scope in ("PILOT_ONLY", "FULL_RESEARCH"), "Unknown research approval scope"
    assert operation in ("pilot", "path", "batch")
    if scope=="PILOT_ONLY":
        assert operation=="pilot", "Pilot approval cannot authorize a path or batch"
        allowed=approval.get("allowed_single_case", {})
        assert {"family":family,"seed":seed,"variant":variants[0] if variants and len(variants)==1 else None,
                "cost":cost_names[0] if cost_names and len(cost_names)==1 else None}==allowed
        assert family in model.FAMILIES and seed in ctx["discovery_seeds"]
        assert variants==["current"] and cost_names==["current"]
        return
    if operation=="batch":
        return  # Every worker must separately pass the case and validation-lock checks.
    assert family in model.FAMILIES
    split=model.require_seed(ctx,seed)
    assert variants and len(set(variants))==len(variants)
    assert set(variants)<=set(ctx["candidate_labels"])
    assert cost_names and len(set(cost_names))==len(cost_names)
    allowed_costs={"current","stress","tail50"} if family=="common_shocks" else {"current","stress"}
    assert set(cost_names)<=allowed_costs
    if split=="validation":
        selection=json.loads((OUT/"Discovery-Selection.json").read_text())
        assert set(variants)<={"current",selection["winner"]}


def model_approved(*, operation, ctx, family=None, seed=None, variants=None, cost_names=None):
    model.check_lock()
    approval=json.loads((OUT/"Model-Approval.json").read_text())
    assert approval["approved"] is True
    assert approval["model_contract_sha256"]==model.file_hash(OUT/"Model-Contract.json")
    assert approval["harness_sha256"]==model.file_hash(__file__)
    assert approval["diagnostics_sha256"]==model.file_hash(OUT/"diagnostics.py")
    authorize_request(approval,operation=operation,ctx=ctx,family=family,seed=seed,
                      variants=variants,cost_names=cost_names)


def execute_path(family,seed,variants=None,cost_names=None,pilot=False):
    ctx=model.context();split=model.require_seed(ctx,seed)
    variants=ctx["candidate_labels"] if variants is None else variants
    if split=="validation":
        selection=json.loads((OUT/"Discovery-Selection.json").read_text())
        allowed={"current",selection["winner"]}
        assert set(variants)<=allowed
    assert set(variants)<=set(ctx["candidate_labels"])
    cost_names=(["current","stress","tail50"] if family=="common_shocks" else ["current","stress"]) if cost_names is None else cost_names
    operation="pilot" if pilot else "path"
    model_approved(operation=operation,ctx=ctx,family=family,seed=seed,variants=variants,cost_names=cost_names)
    dest=model.save_path(family,seed)
    meta=json.loads((dest/"Manifest.json").read_text())
    diagnostic=diagnostics.audit_path(dest)
    assert diagnostic["hard_checks"]["pass"]
    with np.load(dest/"Path.npz",allow_pickle=False) as src:
        values,proxy=src["values"],src["proxy"]
    data=candles_from(values,ctx)
    outputs=[];rules=rules_from(ctx);seedcash=D(ctx["starting_cash_usdc"])
    for variant in variants:
        for cost in cost_names:
            model_approved(operation=operation,ctx=ctx,family=family,seed=seed,variants=[variant],cost_names=[cost])
            target=OUT/("pilot" if pilot else "runs")/split/f"{model.FAMILIES.index(family)}-{seed}"/f"{variant}-{cost}"
            target.mkdir(parents=True,exist_ok=True)
            identity={"family":family,"seed":seed,"split":split,"variant":variant,"cost":cost,
                "source_sha256":ctx["source_sha256"],"context_sha256":model.file_hash(OUT/"Context.json"),
                "model_contract_sha256":model.file_hash(OUT/"Model-Contract.json"),
                "path_file_sha256":meta["path_file_sha256"],"harness_sha256":model.file_hash(__file__),
                "diagnostics_sha256":model.file_hash(OUT/"diagnostics.py")}
            if split=="validation":
                identity["discovery_selection_sha256"]=model.file_hash(OUT/"Discovery-Selection.json")
            complete=target/"Complete.json"
            if complete.exists():
                old=json.loads(complete.read_text());assert old["identity"]==identity
                assert all(model.file_hash(target/name)==sha for name,sha in old["files"].items())
                outputs.append(str(target));continue
            low_priority_and_peak_mb();began=time.monotonic()
            result=run_shared_portfolio_backtest(candles_by_symbol=data,report_start_utc=datetime.fromisoformat(ctx["anchor_utc"]),
                report_end_utc=datetime.fromisoformat(ctx["five_year_end_utc"]),starting_cash=seedcash,
                target_notional=(seedcash/2).quantize(D(".01")),slot_count=2,costs=COSTS[cost],
                execution_rules=rules,strategy=candidate(variant),reinvest_profits=True,autonomous_spot=True)
            native_done=time.monotonic()
            checks,liquidity,orders,percoin=audit_ledger(result,data,proxy)
            ledger_done=time.monotonic()
            topwins=sorted((t.realized_pnl for t in result.trades if t.realized_pnl>0),reverse=True)
            row={**identity,"metrics":asdict(result.metrics),"native_engine":True,
                "technical_checks":checks,"liquidity":liquidity,"per_coin":percoin,
                "timing":{"seconds":ledger_done-began,"native_engine_seconds":native_done-began,
                          "ledger_seconds":ledger_done-native_done,"peak_rss_mb":low_priority_and_peak_mb()},
                "max_equity":max(p.equity for p in result.equity_curve),
                "top3_positive_exit_legs_share":sum(topwins[:3],D(0))/sum(topwins,D(0)) if topwins else None,
                "blocked_reasons":dict(Counter(x.rsplit(":",1)[-1] for x in result.blocked_signals)),
                "open_symbols_at_end":result.open_symbols_at_end,"research_only":True}
            model.write(target/"Result.json",row)
            model.write(target/"Trades.json",[asdict(t) for t in result.trades])
            model.write(target/"Fills.json",[asdict(f) for f in result.fills])
            model.write(target/"Signals.json",[asdict(s) for s in result.signals])
            model.write(target/"Liquidity.json",orders)
            with gzip.open(target/"Equity.csv.gz","wt",encoding="utf-8",newline="") as stream:
                writer=csv.writer(stream);writer.writerow(["time_utc","equity","cash","position_value"])
                writer.writerows((p.time_utc.isoformat(),p.equity,p.cash,p.position_value) for p in result.equity_curve)
            assert source_fingerprint()==ctx["source_sha256"]
            names=("Result.json","Trades.json","Fills.json","Signals.json","Liquidity.json","Equity.csv.gz")
            model.write(complete,{"identity":identity,"files":{name:model.file_hash(target/name) for name in names},"complete":True})
            outputs.append(str(target))
            print(json.dumps({**identity,"end":str(result.metrics.ending_equity),"dd":str(result.metrics.max_drawdown_pct),"seconds":row["timing"]["seconds"],"rss_mb":row["timing"]["peak_rss_mb"]}),flush=True)
    return outputs


def benchmark():
    """Known historical baseline only, no unknown scenario or candidate PnL."""
    ctx=model.context()
    with gzip.open(ctx["donor_file"],"rt",encoding="utf-8") as stream:
        raw=json.load(stream)
    definition=strategy_definition("v8r")
    data={s:[model._candle(r) for r in raw[s]] for s in definition.symbols}
    manifest=json.loads(model.Path(ctx["donor_manifest"]).read_text())
    began=time.monotonic();low_priority_and_peak_mb()
    result=run_shared_portfolio_backtest(candles_by_symbol=data,
        report_start_utc=datetime.fromisoformat(manifest["data"]["report_start_utc"]),
        report_end_utc=datetime.fromisoformat(manifest["data"]["report_end_utc"]),
        starting_cash=D("1039.26093944"),target_notional=D("519.63"),slot_count=2,
        costs=CURRENT_COSTS,execution_rules=rules_from(ctx),strategy=definition,
        reinvest_profits=True,autonomous_spot=True)
    assert result.metrics.ending_equity==D("21558.10100828973055000000")
    assert result.metrics.max_drawdown_pct==D("38.21399695102633872563582372")
    row={"known_historical_control":True,"source_sha256":ctx["source_sha256"],
         "native_engine":True,"metrics":asdict(result.metrics),"seconds":time.monotonic()-began,
         "peak_rss_mb":low_priority_and_peak_mb(),"exact_ending_and_dd_match":True}
    model.write(OUT/"Native-Benchmark.json",row);print(json.dumps(row,default=str),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("mode",choices=("benchmark","pilot","path","batch"))
    parser.add_argument("--family",choices=model.FAMILIES,default=model.FAMILIES[0]);parser.add_argument("--seed",type=int,default=251001)
    parser.add_argument("--split",choices=("discovery","validation"),default="discovery")
    parser.add_argument("--workers",type=int,choices=(1,2),default=1)
    args=parser.parse_args()
    if args.mode=="benchmark":
        benchmark();return
    if args.mode=="pilot":
        execute_path(args.family,args.seed,["current"],["current"],pilot=True);return
    if args.mode=="path":
        execute_path(args.family,args.seed);return
    ctx=model.context();model_approved(operation="batch",ctx=ctx);seeds=ctx[args.split+"_seeds"]
    variants=ctx["candidate_labels"]
    if args.split=="validation":
        model.require_seed(ctx,seeds[0]);selection=json.loads((OUT/"Discovery-Selection.json").read_text())
        variants=list(dict.fromkeys(["current",selection["winner"]]))
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        jobs={pool.submit(execute_path,family,seed,variants):[family,seed] for family in model.FAMILIES for seed in seeds}
        for future in as_completed(jobs):
            future.result()
            model.write(OUT/"Progress.json",{"last_completed":jobs[future],"completed_paths":sum(f.done() and f.exception() is None for f in jobs),
                                              "split":args.split,"total_paths":len(jobs)})


if __name__=="__main__":
    main()
