"""Price-path diagnostics, deliberately independent of bot performance."""
import json
from datetime import UTC, datetime

import numpy as np

import model


def quantiles(values, weights=None):
    values=np.asarray(values).reshape(-1)
    if weights is None:
        return np.quantile(values,[.01,.1,.5,.9,.99]).tolist()
    weights=np.asarray(weights).reshape(-1)
    order=np.argsort(values)
    cumulative=np.cumsum(weights[order])
    return np.interp(np.array([.01,.1,.5,.9,.99])*cumulative[-1],cumulative,values[order]).tolist()


def correlations(returns, weights=None):
    if weights is None:
        cov=np.cov(returns,rowvar=False)
    else:
        w=weights/weights.sum()
        centered=returns-np.sum(returns*w[:,None],axis=0)
        cov=(centered*w[:,None]).T@centered
    sd=np.sqrt(np.diag(cov))
    matrix=cov/np.maximum(sd[:,None]*sd[None,:],1e-30)
    return quantiles(matrix[np.triu_indices(returns.shape[1],1)])


def profile(values, previous_close, weights=None):
    returns=np.log(values[:,:,model.C]/previous_close)
    common_tail=np.sum(returns<np.log(.95),axis=1)>=8
    tail_rate=float(np.mean(common_tail)) if weights is None else float(np.sum(weights*common_tail)/np.sum(weights))
    acf={}
    for lag in (1,24,168):
        acf[str(lag)]=[]
        for j in range(returns.shape[1]):
            a,b=np.abs(returns[lag:,j]),np.abs(returns[:-lag,j])
            w=None if weights is None else weights[lag:]
            if w is None:
                v=float(np.corrcoef(a,b)[0,1])
            else:
                w=w/w.sum();da=a-np.sum(w*a);db=b-np.sum(w*b)
                v=float(np.sum(w*da*db)/max(np.sqrt(np.sum(w*da*da)*np.sum(w*db*db)),1e-30))
            acf[str(lag)].append(v if np.isfinite(v) else None)
    rolling={}
    for width in (24,168):
        windows=range(0,len(returns)-width+1,24)
        vols=[];corr=[];ww=[]
        for start in windows:
            part=returns[start:start+width]
            vols.append(float(np.median(np.std(part,axis=0))))
            corr.append(correlations(part)[2])
            ww.append(1. if weights is None else float(np.mean(weights[start:start+width])))
        rolling[str(width)]={"median_crosscoin_volatility_quantiles":quantiles(vols,ww),
                             "median_pair_correlation_quantiles":quantiles(corr,ww)}
    return {"hourly_return_quantiles_by_coin":[quantiles(returns[:,j],weights) for j in range(returns.shape[1])],
        "abs_return_acf_by_coin":acf,"pair_correlation_quantiles":correlations(returns,weights),
        "rolling_24hour_step":rolling,
        "common_minus5pct_hour_count":int(np.sum(common_tail)),
        "common_minus5pct_hour_count_is_unweighted_raw":True,
        "common_minus5pct_hour_rate":tail_rate,
        "gap_quantiles_by_coin":[quantiles(np.log(values[:,j,model.O]/previous_close[:,j]),weights) for j in range(returns.shape[1])],
        "range_quantiles_by_coin":[quantiles(np.log(values[:,j,model.H]/values[:,j,model.L]),weights) for j in range(returns.shape[1])],
        "quote_volume_quantiles_by_coin":[quantiles(values[:,j,model.Q],weights) for j in range(returns.shape[1])]}


def audit_path(dest):
    dest=model.Path(dest)
    meta=json.loads((dest/"Manifest.json").read_text())
    assert model.file_hash(dest/"Path.npz")==meta["path_file_sha256"]
    with np.load(dest/"Path.npz",allow_pickle=False) as src:
        values,idx,blockidx,expected,proxy=(src[k] for k in ("values","donor_index","block_index","expected_weights","proxy"))
    with np.load(model.OUT/"Donors.npz",allow_pickle=False) as src:
        donor,times,symbols=(src[k] for k in ("values","times","symbols"))
    future=values[model.WARM:];previous=values[model.WARM-1:-1,:,model.C]
    raw=donor[idx]
    shock=np.ones((len(idx),len(symbols)));qfactor=np.ones(len(idx))
    for event in meta["shocks"]:
        at=event["hour"]
        if at<len(idx):
            shock[at]=event["factors"]
            qfactor[at:at+event["quote_hours"]]*=event["quote_factor"]
    donor_gap=raw[:,:,model.O]/donor[idx-1,:,model.C]
    observed_gap=future[:,:,model.O]/previous
    gap_error=float(np.max(np.abs(observed_gap/(donor_gap*shock)-1)))
    scale=future[:,:,model.O]/raw[:,:,model.O]
    shape_error=float(np.max(np.abs(future[:,:,:4]/(raw[:,:,:4]*scale[:,:,None])-1)))
    volume_error=float(np.max(np.abs(future[:,:,model.V]*scale-raw[:,:,model.V]*qfactor[:,None])))
    quote_error=float(np.max(np.abs(future[:,:,model.Q]-raw[:,:,model.Q]*qfactor[:,None])))
    assert gap_error<3e-12 and shape_error<3e-12
    assert np.allclose(future[:,:,model.V]*scale,raw[:,:,model.V]*qfactor[:,None],rtol=3e-12,atol=1e-10)
    assert quote_error==0
    reuse=np.bincount(idx,minlength=len(donor))
    month_counts={}
    for i,count in enumerate(reuse):
        if count:
            month=datetime.fromtimestamp(int(times[i])*3600,UTC).strftime("%Y-%m")
            month_counts[month]=month_counts.get(month,0)+int(count)
    shares=np.asarray(list(month_counts.values()))/len(idx)
    seam=np.concatenate([[True],np.diff(blockidx)!=0])
    shockhours=np.any(shock!=1,axis=1)
    mult=future[-1,:,model.C]/values[model.WARM-1,:,model.C]
    years=meta["hours"]/(365.25*24)
    macro_extreme=bool(mult[0]>10 or mult[0]<.1 or mult[1]>20 or mult[1]<.05)
    result={"family":meta["family"],"seed":meta["seed"],"path_file_sha256":meta["path_file_sha256"],
        "hard_checks":{"pass":True,"max_relative_gap_error":gap_error,
                       "max_relative_shape_error":shape_error,"max_base_volume_absolute_error":volume_error,
                       "max_quote_volume_absolute_error":quote_error},
        "coverage":{"unique_donor_months":len(month_counts),"month_counts":month_counts,
                    "unique_block_pairs":len({(b['donor_start'],b['nominal_length']) for b in meta['blocks']}),
                    "max_hour_reuse":int(reuse.max()),"top3_month_share":float(np.sort(shares)[-3:].sum()),
                    "effective_month_count":float(1/np.sum(shares**2)),
                    "same_donor_time_for_all15":True,"proxy_share_by_coin":proxy.mean(axis=0).tolist()},
        "end_price_multiple_by_coin":dict(zip(symbols.tolist(),mult.tolist(),strict=True)),
        "price_cagr_by_coin":dict(zip(symbols.tolist(),(mult**(1/years)-1).tolist(),strict=True)),
        "macro_extreme_context_flag":macro_extreme,
        "macro_flag_note":"Heuristic context flag only: BTC outside .1..10x or ETH .05..20x. Not a fitted confidence interval; never reject/reseed based on bot profit.",
        "synthetic_profile":profile(future,previous),
        "weighted_donor_pool_profile":profile(donor[1:],donor[:-1,:,model.C],expected[1:]),
        "seam_return_quantiles":quantiles(np.log(future[seam,:,model.C]/previous[seam])),
        "internal_return_quantiles":quantiles(np.log(future[~seam,:,model.C]/previous[~seam])),
        "shock_hour_count":int(shockhours.sum()),"not_model_or_performance_approval":True,
        "limits":"Three-year selected donor history can be bullish and lacks 2022. Weighted overlapping donor-window profiles are reference diagnostics, not theoretical bootstrap distributions or future probabilities."}
    model.write(dest/"Diagnostics.json",result)
    return result
