"""Frozen, profit-first study selection and transparent paired validation.

Reads only complete, hash-verified research runs. Does not import the live bot,
credentials or order clients. Other random seeds are not real unseen history.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import UTC, datetime
from decimal import Decimal as D
from pathlib import Path
from statistics import median

OUT = Path(__file__).resolve().parent
ARTIFACTS = {"Result.json", "Trades.json", "Fills.json", "Signals.json",
             "Liquidity.json", "Equity.csv.gz"}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write(path, obj):
    temporary = Path(path).with_suffix(".tmp.json")
    temporary.write_text(json.dumps(obj, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def cost_name(row):
    cost = row["cost"]
    return cost["name"] if isinstance(cost, dict) else cost


def number(row, name):
    value = D(str(row["metrics"][name]))
    assert value.is_finite(), (name, row.get("family"), row.get("seed"))
    return value


def bound_inputs():
    context = load(OUT / "Context.json")
    approval = load(OUT / "Study-Approval.json")
    contract = load(OUT / "Model-Contract.json")
    assert approval["context_sha256"] == digest(OUT / "Context.json")
    assert contract["context_sha256"] == digest(OUT / "Context.json")
    assert contract["approval_sha256"] == digest(OUT / "Study-Approval.json")
    assert contract["source"] == context["source_sha256"]
    assert contract["generator_sha256"] == digest(OUT / "model.py")
    assert contract["prepared_sha256"] == digest(OUT / "Prepared.json")
    return context


def expected(context, split, variants):
    seeds = context["discovery_seeds" if split == "discovery" else "validation_seeds"]
    return {
        (family, seed, variant, cost)
        for family in context["families"]
        for seed in seeds
        for variant in variants
        for cost in (("current", "stress", "tail50")
                     if family == "common_shocks" else ("current", "stress"))
    }


def results(split):
    context = bound_inputs()
    rows = {}
    for path in sorted((OUT / "runs" / split).rglob("Result.json")):
        complete_path = path.with_name("Complete.json")
        if not complete_path.exists():
            continue  # Partial Result.json is never treated as a finished case.
        complete = load(complete_path)
        hashes = complete.get("files", complete.get("file_hashes"))
        assert complete["complete"] is True
        assert isinstance(hashes, dict) and set(hashes) == ARTIFACTS, complete_path
        for name, expected_hash in hashes.items():
            target = (path.parent / name).resolve()
            assert target.is_relative_to(path.parent.resolve())
            assert digest(target) == expected_hash, target
        assert "Result.json" in hashes
        row = load(path)
        assert all(row.get(key) == value for key, value in complete["identity"].items())
        assert row["source_sha256"] == context["source_sha256"]
        assert row["context_sha256"] == digest(OUT / "Context.json")
        assert row["model_contract_sha256"] == digest(OUT / "Model-Contract.json")
        assert row["split"] == split
        assert row["harness_sha256"] == digest(OUT / "native_study.py")
        assert row["diagnostics_sha256"] == digest(OUT / "diagnostics.py")
        key = row["family"], row["seed"], row["variant"], cost_name(row)
        assert key not in rows, key
        row["result_sha256"] = digest(path)
        row["result_path"] = str(path.relative_to(OUT))
        row["complete_path"] = str(complete_path.relative_to(OUT))
        row["complete_sha256"] = digest(complete_path)
        rows[key] = row
    return context, rows


def technically_valid(row):
    required = ("cash_equity", "nonnegative", "causality", "dd_recomputed")
    return all(row["technical_checks"].get(name) is True for name in required)


def select():
    path = OUT / "Discovery-Selection.json"
    assert not path.exists(), "Selection must not be overwritten after observing validation"
    context, rows = results("discovery")
    wanted = expected(context, "discovery", context["candidate_labels"])
    assert set(rows) == wanted, {"missing": sorted(wanted - set(rows)),
                                 "unexpected": sorted(set(rows) - wanted)}
    summary = {}
    for variant in context["candidate_labels"]:
        normal = [r for k, r in rows.items() if k[2:] == (variant, "current")]
        stress = [r for k, r in rows.items() if k[2:] == (variant, "stress")]
        assert len(normal) == len(stress) == 12
        own = [r for k, r in rows.items() if k[2] == variant]
        summary[variant] = {
            "normal_median_net": median(number(r, "net_pnl") for r in normal),
            "normal_median_close_dd": median(number(r, "max_drawdown_pct") for r in normal),
            "stress_median_net": median(number(r, "net_pnl") for r in stress),
            "normal_worst_end": min(number(r, "ending_equity") for r in normal),
            "normal_worst_close_dd": max(number(r, "max_drawdown_pct") for r in normal),
            "stress_worst_end": min(number(r, "ending_equity") for r in stress),
            "stress_worst_close_dd": max(number(r, "max_drawdown_pct") for r in stress),
            "technical_valid": all(technically_valid(r) for r in own),
            "all_discovery_runs": len(own),
        }
    base = summary["current"]
    assert base["technical_valid"], "A baseline technical violation needs repair, not alpha selection"
    for s in summary.values():
        s["eligible"] = bool(s["technical_valid"]
            and s["normal_median_net"] >= base["normal_median_net"]
            and s["stress_median_net"] >= base["stress_median_net"])
    eligible = [v for v in context["candidate_labels"] if summary[v]["eligible"]]
    chosen = sorted(eligible, key=lambda v: (
        -summary[v]["normal_median_net"], summary[v]["normal_median_close_dd"],
        context["candidate_labels"].index(v)))[0]
    selection = {
        "frozen_at_utc": datetime.now(UTC).isoformat(),
        "context_sha256": digest(OUT / "Context.json"),
        "model_contract_sha256": digest(OUT / "Model-Contract.json"),
        "study_approval_sha256": digest(OUT / "Study-Approval.json"),
        "selection_script_sha256": digest(__file__),
        "source_sha256": context["source_sha256"],
        "winner": chosen, "discovery_complete": True,
        "discovery_case_count": len(rows), "summary": summary,
        "discovery_result_sha256": {r["result_path"]: r["result_sha256"] for r in rows.values()},
        "discovery_complete_sha256": {r["complete_path"]: r["complete_sha256"] for r in rows.values()},
        "not_a_product_promotion": True,
        "known_donors_not_real_out_of_sample": True,
        "selection_rule": "Normal median net first; normal median closing DD second; fixed order last. Stress median net cannot regress. No worst-DD hard gate.",
    }
    write(path, selection)
    print(json.dumps({"winner": chosen, "cases": len(rows), "summary": summary}, default=str), flush=True)


def validate():
    selection = load(OUT / "Discovery-Selection.json")
    assert selection["selection_script_sha256"] == digest(__file__), "Frozen selection code changed"
    context = bound_inputs()
    assert selection["context_sha256"] == digest(OUT / "Context.json")
    assert selection["model_contract_sha256"] == digest(OUT / "Model-Contract.json")
    assert selection["study_approval_sha256"] == digest(OUT / "Study-Approval.json")
    assert selection["source_sha256"] == context["source_sha256"]
    assert selection["discovery_complete"] is True
    _, discovery = results("discovery")
    assert set(discovery) == expected(context, "discovery", context["candidate_labels"])
    assert selection["discovery_result_sha256"] == {
        r["result_path"]: r["result_sha256"] for r in discovery.values()}
    assert selection["discovery_complete_sha256"] == {
        r["complete_path"]: r["complete_sha256"] for r in discovery.values()}
    context, rows = results("validation")
    winner = selection["winner"]
    variants = list(dict.fromkeys(["current", winner]))
    wanted = expected(context, "validation", variants)
    assert set(rows) == wanted, {"missing": sorted(wanted - set(rows)),
                                 "unexpected": sorted(set(rows) - wanted)}
    assert all(technically_valid(r) for r in rows.values())
    for row in rows.values():
        assert row["discovery_selection_sha256"] == digest(OUT / "Discovery-Selection.json")
    paired = []
    for family in context["families"]:
        for seed in context["validation_seeds"]:
            for cost in (("current", "stress", "tail50")
                         if family == "common_shocks" else ("current", "stress")):
                base = rows[family, seed, "current", cost]
                other = rows[family, seed, winner, cost]
                paired.append({"family": family, "seed": seed, "cost": cost,
                    "baseline_end": number(base, "ending_equity"),
                    "winner_end": number(other, "ending_equity"),
                    "net_advantage": number(other, "net_pnl") - number(base, "net_pnl"),
                    "baseline_close_dd": number(base, "max_drawdown_pct"),
                    "winner_close_dd": number(other, "max_drawdown_pct")})
    normal = [r for r in paired if r["cost"] == "current"]
    stress = [r for r in paired if r["cost"] == "stress"]
    normal_advantage = median(r["net_advantage"] for r in normal)
    stress_advantage = median(r["net_advantage"] for r in stress)
    nonworse = sum(r["net_advantage"] >= 0 for r in normal)
    passes = bool(winner != "current" and normal_advantage >= 0
                  and stress_advantage >= 0 and nonworse >= 7)
    report = {"winner": winner, "validation_cases": len(rows), "paired": paired,
              "normal_paired_median_net_advantage": normal_advantage,
              "stress_paired_median_net_advantage": stress_advantage,
              "normal_nonworse_paths": nonworse,
              "normal_strictly_better_paths": sum(r["net_advantage"] > 0 for r in normal),
              "normal_strictly_worse_paths": sum(r["net_advantage"] < 0 for r in normal),
              "normal_equal_paths": sum(r["net_advantage"] == 0 for r in normal),
              "predeclared_model_validation_pass": passes,
              "decision": "RESEARCH_CANDIDATE_ONLY" if passes else "NO_CHANGE",
              "product_promotion_allowed": False,
              "future_probabilities_estimated": False,
              "discovery_selection_sha256": digest(OUT / "Discovery-Selection.json"),
              "nonregression_is_not_proof_of_strict_profit_improvement": True,
              "validation_result_sha256": {r["result_path"]: r["result_sha256"] for r in rows.values()},
              "validation_complete_sha256": {r["complete_path"]: r["complete_sha256"] for r in rows.values()}}
    write(OUT / "Validation-Summary.json", report)
    print(json.dumps(report, default=str), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=("select", "validate"))
    mode = parser.parse_args().mode
    select() if mode == "select" else validate()
