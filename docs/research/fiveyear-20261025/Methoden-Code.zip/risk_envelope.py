"""Supplemental OHLC stress marks under the unchanged native fills.

This is NOT an observed intrahour equity curve, a guaranteed loss bound or a
new entry/exit rule. It assumes all held assets' hourly highs precede their
hourly lows simultaneously, an intentionally conservative OHLC construction.
Independent exact Decimal ledger checks remain in native_study.py.
"""
from __future__ import annotations

import csv
import gzip
import json
from datetime import datetime
from pathlib import Path

import numpy as np

import model


def analyze(result_path):
    result_path = Path(result_path)
    row = json.loads(result_path.read_text())
    complete = json.loads(result_path.with_name("Complete.json").read_text())
    assert all(model.file_hash(result_path.parent / n) == h
               for n, h in complete["files"].items())
    context = model.context()
    manifest_path = model.OUT / "paths" / f"{model.FAMILIES.index(row['family'])}-{row['seed']}"
    manifest = json.loads((manifest_path / "Manifest.json").read_text())
    assert manifest["path_file_sha256"] == row["path_file_sha256"]
    assert model.file_hash(manifest_path / "Path.npz") == row["path_file_sha256"]
    with np.load(manifest_path / "Path.npz", allow_pickle=False) as src:
        values = src["values"][model.WARM:]
    symbols = list(context["execution_rules"])
    # Context dictionary order is not a substitute for the actual model column order.
    with np.load(model.OUT / "Donors.npz", allow_pickle=False) as src:
        symbols = src["symbols"].tolist()
    lookup = {s["signal_id"]: s["symbol"]
              for s in json.loads(result_path.with_name("Signals.json").read_text())}
    fills = json.loads(result_path.with_name("Fills.json").read_text())
    initial = float(context["starting_cash_usdc"])
    changes = np.zeros((len(values), len(symbols)))
    cash_changes = np.zeros(len(values))
    anchor = datetime.fromisoformat(context["anchor_utc"])
    for fill in fills:
        at = datetime.fromisoformat(fill["fill_time_utc"])
        i = int((at - anchor).total_seconds() / 3600)
        assert 0 <= i < len(values)
        symbol = lookup[fill["signal_id"]]
        j = symbols.index(symbol)
        buy = fill["action"] == "ENTER_LONG"
        changes[i, j] += float(fill["base_quantity"]) * (1 if buy else -1)
        cash_changes[i] += (-float(fill["quote_value"]) if buy else
                           float(fill["quote_value"]) - float(fill["fee_quote_equivalent"]))
    owned = np.cumsum(changes, axis=0)
    cash = initial + np.cumsum(cash_changes)
    assert float(owned.min()) > -1e-7 and float(cash.min()) > -1e-7
    close_marks = cash + np.sum(owned * values[:, :, model.C], axis=1)
    with gzip.open(result_path.with_name("Equity.csv.gz"), "rt", encoding="utf-8") as stream:
        saved = np.asarray([float(r["equity"]) for r in csv.DictReader(stream)])
    assert np.allclose(close_marks, saved, rtol=1e-11, atol=1e-7)
    high_marks = cash + np.sum(owned * values[:, :, model.H], axis=1)
    low_marks = cash + np.sum(owned * values[:, :, model.L], axis=1)
    assumed_peak = np.maximum.accumulate(np.maximum(high_marks, initial))
    stress_dd = (assumed_peak - low_marks) / assumed_peak * 100
    worst = int(np.argmax(stress_dd))
    report = {
        "family": row["family"], "seed": row["seed"], "split": row["split"],
        "variant": row["variant"], "cost": row["cost"],
        "result_sha256": model.file_hash(result_path),
        "path_file_sha256": row["path_file_sha256"],
        "native_closing_drawdown_pct": row["metrics"]["max_drawdown_pct"],
        "assumed_synchronous_high_before_low_drawdown_pct": float(stress_dd[worst]),
        "worst_model_hour_index": worst,
        "closing_equity_max_float_reconstruction_error_usdc": float(np.max(np.abs(close_marks-saved))),
        "not_actual_intrabar_path_or_exchange_fill": True,
        "does_not_include_exchange_or_process_outages": True,
    }
    model.write(result_path.with_name("OHLC-Stress-Envelope.json"), report)
    return report


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("result", type=Path)
    print(json.dumps(analyze(parser.parse_args().result), indent=2))
