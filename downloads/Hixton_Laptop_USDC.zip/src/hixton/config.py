"""Strict, secret-free JSON configuration for the active paper strategy."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path
from typing import Any

from hixton.domain.capital import DEFAULT_MAX_CAPITAL_USDC, capital_plan
from hixton.domain.versions import strategy_definition


@dataclass(frozen=True, slots=True)
class ProjectConfig:
    strategy_key: str
    database_path: Path
    run_output_root: Path
    binance_base_url: str
    starting_usdc_per_symbol: Decimal
    target_notional_usdc: Decimal
    run_baseline_and_stress: bool
    paper_poll_seconds: int
    paper_starting_cash_usdc: Decimal
    paper_slot_count: int
    paper_target_notional_usdc: Decimal
    daily_audit_utc: str
    ui_bind: str
    ui_port: int
    ui_timezone: str
    ui_default_range: str
    sha256: str
    paper_max_capital_usdc: Decimal = DEFAULT_MAX_CAPITAL_USDC


def _required_mapping(value: object, name: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise ValueError(f"{name} must be an object")
    return value


def _reject_unknown(mapping: dict[str, Any], allowed: set[str], name: str) -> None:
    unknown = set(mapping) - allowed
    if unknown:
        raise ValueError(f"unknown {name} fields: {', '.join(sorted(unknown))}")


def load_project_config(path: Path, *, project_root: Path) -> ProjectConfig:
    raw_text = path.read_text(encoding="utf-8")
    payload = json.loads(raw_text)
    root = _required_mapping(payload, "configuration")
    _reject_unknown(
        root,
        {"schema_version", "strategy", "markets", "backtest", "paper", "ui", "runtime"},
        "root",
    )
    if root.get("schema_version") != 1:
        raise ValueError("schema_version must be 1")

    strategy = _required_mapping(root.get("strategy"), "strategy")
    _reject_unknown(strategy, {"key"}, "strategy")
    strategy_key = str(strategy.get("key", "")).lower()
    if strategy_key not in {"v6", "v8"}:
        raise ValueError(
            "product configuration supports the frozen V6 Core and current V8 strategy"
        )
    definition = strategy_definition(strategy_key)
    if not definition.paper_approved:
        raise ValueError(f"strategy {definition.version} is not approved for paper")

    markets = root.get("markets")
    if not isinstance(markets, list) or tuple(markets) != definition.symbols:
        raise ValueError("markets must contain the active strategy symbols in fixed order")

    backtest = _required_mapping(root.get("backtest"), "backtest")
    _reject_unknown(
        backtest,
        {
            "starting_usdc_per_symbol",
            "target_notional_usdc",
            "primary_window_years",
        },
        "backtest",
    )
    if backtest.get("primary_window_years") != 3:
        raise ValueError("primary_window_years must be 3")
    starting = Decimal(str(backtest.get("starting_usdc_per_symbol")))
    target = Decimal(str(backtest.get("target_notional_usdc")))
    if starting <= 0 or target <= 0:
        raise ValueError("backtest capital inputs must be positive")

    paper = _required_mapping(root.get("paper"), "paper")
    _reject_unknown(
        paper,
        {"starting_cash_usdc", "max_capital_usdc", "poll_seconds", "daily_audit_utc"},
        "paper",
    )
    if paper.get("poll_seconds") != 30 or paper.get("daily_audit_utc") != "00:05":
        raise ValueError("paper timing settings must use the canonical values")
    paper_max_capital = Decimal(str(paper["max_capital_usdc"]))
    paper_plan = capital_plan(paper_max_capital)
    paper_starting_cash = Decimal(str(paper["starting_cash_usdc"]))
    if paper_starting_cash != paper_plan.max_capital_usdc:
        raise ValueError(
            "paper starting cash must equal configured max capital; "
            "the allocator derives two 50-percent slots from that amount"
        )

    ui = _required_mapping(root.get("ui"), "ui")
    expected_ui: dict[str, object] = {
        "bind": "127.0.0.1",
        "port": 8765,
        "timezone": "Europe/Berlin",
        "default_range": "1m",
    }
    _reject_unknown(ui, set(expected_ui), "ui")
    if ui != expected_ui:
        raise ValueError("UI settings must use the documented localhost settings")

    runtime = _required_mapping(root.get("runtime"), "runtime")
    _reject_unknown(runtime, {"database_path", "run_output_root", "binance_base_url"}, "runtime")
    database_path = project_root / str(runtime.get("database_path", "data/hixton.sqlite3"))
    run_output_root = project_root / str(
        runtime.get("run_output_root", f"backtests/{definition.backtest_version}/runs")
    )
    digest = hashlib.sha256(
        json.dumps(root, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()
    return ProjectConfig(
        strategy_key=definition.key,
        database_path=database_path,
        run_output_root=run_output_root,
        binance_base_url=str(runtime.get("binance_base_url", "https://api.binance.com")),
        starting_usdc_per_symbol=starting,
        target_notional_usdc=target,
        run_baseline_and_stress=False,
        paper_poll_seconds=int(paper["poll_seconds"]),
        paper_starting_cash_usdc=paper_starting_cash,
        paper_slot_count=paper_plan.slot_count,
        paper_target_notional_usdc=paper_plan.target_notional_usdc,
        daily_audit_utc=str(paper["daily_audit_utc"]),
        ui_bind=str(ui["bind"]),
        ui_port=int(ui["port"]),
        ui_timezone=str(ui["timezone"]),
        ui_default_range=str(ui["default_range"]),
        sha256=digest,
        paper_max_capital_usdc=paper_plan.max_capital_usdc,
    )
