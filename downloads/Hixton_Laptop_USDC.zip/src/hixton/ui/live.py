"""Password/session protected localhost routes for credential and preflight setup."""

from __future__ import annotations

import json
import sqlite3
from collections.abc import Callable
from decimal import Decimal, InvalidOperation
from functools import partial
from typing import Any

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from starlette.concurrency import run_in_threadpool

from hixton.backtest.models import ExecutionRules
from hixton.backtest.reporting import source_fingerprint
from hixton.config import ProjectConfig
from hixton.data.storage import CandleStore
from hixton.live.binance import BinanceCheckError, BinanceReadOnlyClient
from hixton.live.credentials import BinanceCredentials, Vault, VaultError, WindowsVault
from hixton.live.preparation import LivePreparation
from hixton.paper.storage import PaperStore
from hixton.runtime.supervisor import RuntimeSupervisor

_COOKIE = "hixton_live_session"


def install_live_routes(
    app: FastAPI,
    config: ProjectConfig,
    supervisor: RuntimeSupervisor,
    local_action: Callable[[Request], bool],
    vault: Vault | None = None,
) -> None:
    service = LivePreparation(
        config.database_path.with_name("live-preparation.sqlite3"),
        vault if vault is not None else WindowsVault(config.database_path),
        client_factory=partial(
            BinanceReadOnlyClient, quote_asset="USDC", market_symbols=supervisor.strategy.symbols
        ),
        execution_source_sha256=supervisor.execution_source_sha256,
        source_is_current=lambda: source_fingerprint() == supervisor.execution_source_sha256,
    )
    app.state.live_preparation = service

    def trading_settings() -> tuple[Decimal, bool]:
        with PaperStore(config.database_path) as store:
            settings = store.load_settings()
        return settings.max_capital_usdc, settings.emergency_stop

    def gap_fillers_enabled() -> bool:
        with PaperStore(config.database_path) as store:
            return store.load_settings().gap_fillers_enabled

    def execution_rules() -> dict[str, ExecutionRules]:
        result: dict[str, ExecutionRules] = {}
        with CandleStore(config.database_path) as store:
            for symbol in supervisor.strategy.symbols:
                stored = store.load_symbol_rules(symbol)
                if stored is None:
                    raise RuntimeError(f"Binance-Orderfilter fehlen für {symbol}")
                result[symbol] = ExecutionRules(
                    tick_size=stored.tick_size,
                    step_size=stored.step_size,
                    min_qty=stored.min_qty,
                    min_notional=stored.min_notional,
                )
        return result

    supervisor.trial_runtime = service.connect_runtime(
        supervisor.strategy,
        settings_provider=trading_settings,
        gap_fillers_enabled=gap_fillers_enabled,
        rules_provider=execution_rules,
    )
    supervisor.live_runtime = service.live_runtime
    supervisor.execution_reporter = lambda: service.write_diagnostic_report(config.database_path)

    def require_local(request: Request) -> None:
        # Unlike legacy read/Paper endpoints, private actions require an exact origin.
        if not local_action(request) or request.headers.get("origin") != str(
            request.base_url
        ).rstrip("/"):
            raise HTTPException(403, "Nur bestätigte Aktionen aus der lokalen Hixton-Oberfläche.")

    def require_session(request: Request) -> None:
        require_local(request)
        if not service.access.authorized(request.cookies.get(_COOKIE)):
            raise HTTPException(
                401, "Geschützten Bereich zuerst mit dem lokalen Passwort entsperren."
            )

    async def payload(request: Request) -> dict[str, Any]:
        # Manual parsing prevents framework validation responses from echoing secret inputs.
        raw = bytearray()
        async for chunk in request.stream():
            raw.extend(chunk)
            if len(raw) > 4096:
                raise HTTPException(413, "Eingabe überschreitet das Größenlimit.")
        try:
            data = json.loads(raw)
            if not isinstance(data, dict):
                raise ValueError
            return data
        except (ValueError, UnicodeError):
            raise HTTPException(400, "Ungültige Eingabe.") from None
        finally:
            raw[:] = b"\x00" * len(raw)

    def get_status(authenticated: bool) -> dict[str, object]:
        soak_ready = False
        preview: dict[str, object] | None = None
        shared: dict[str, object] | None = None
        try:
            with PaperStore(config.database_path) as store:
                store.initialize(
                    strategy_key=supervisor.strategy.key,
                    strategy_version=supervisor.strategy.version,
                    starting_cash_usdc=config.paper_starting_cash_usdc,
                )
                store.require_strategy(supervisor.strategy.key, supervisor.strategy.version)
                settings = store.load_settings()
                preview = {
                    "max_capital_usdc": str(settings.max_capital_usdc),
                    "slot_count": settings.slot_count,
                    "target_notional_usdc": str(settings.target_notional_usdc),
                    "reserve_usdc": str(settings.reserve_usdc),
                    "allocation_policy": settings.allocation_policy,
                    "allocator_version": settings.plan.version,
                }
                shared = {
                    **preview,
                    "emergency_stop": settings.emergency_stop,
                    "gap_fillers_enabled": settings.gap_fillers_enabled,
                }
        except (RuntimeError, sqlite3.DatabaseError, KeyError):
            pass
        try:
            with PaperStore(config.database_path) as store:
                soak_ready = store.load_soak_progress().ready
        except (RuntimeError, sqlite3.DatabaseError, KeyError):
            pass
        max_capital = Decimal(str(shared["max_capital_usdc"])) if shared is not None else None
        emergency_stop = bool(shared["emergency_stop"]) if shared is not None else True
        result = service.status(
            authenticated=authenticated,
            soak_ready=soak_ready,
            healthy=supervisor.state.snapshot().health == "HEALTHY",
            max_capital=max_capital,
            emergency_stop=emergency_stop,
        )
        result["paper_settings_preview"] = preview
        # One existing persistent record, not a second editable Live configuration.
        result["trading_settings"] = shared
        blockers = result["blockers"]
        assert isinstance(blockers, list)
        if shared is None:
            blockers.append("Gemeinsame Handelseinstellungen nicht verfügbar.")
        elif shared["emergency_stop"]:
            blockers.append("Gemeinsame Einstiegspause aktiv; keine neuen Einstiege.")
        return result

    @app.exception_handler(VaultError)
    async def vault_error(_: Request, error: VaultError) -> JSONResponse:
        return JSONResponse({"detail": str(error)}, status_code=400)

    @app.exception_handler(BinanceCheckError)
    async def check_error(_: Request, error: BinanceCheckError) -> JSONResponse:
        return JSONResponse({"detail": str(error)}, status_code=400)

    @app.get("/api/live/status")
    def live_status(request: Request) -> dict[str, object]:
        return get_status(service.access.authorized(request.cookies.get(_COOKIE)))

    @app.get("/api/live/report")
    @app.post("/api/live/report")
    def live_report(request: Request) -> dict[str, object]:
        require_session(request)
        return service.diagnostic_report(config.database_path)

    @app.get("/api/live/report/download")
    @app.post("/api/live/report/download")
    def live_report_download(request: Request) -> FileResponse:
        require_session(request)
        path = service.write_diagnostic_report(config.database_path)
        return FileResponse(
            path,
            media_type="application/json",
            filename="Hixton-Live-Bericht.json",
            headers={"Cache-Control": "no-store"},
        )

    @app.post("/api/live/unlock")
    async def unlock(request: Request) -> JSONResponse:
        require_local(request)
        data = await payload(request)
        password, repeat = data.get("password"), data.get("repeat")
        if not isinstance(password, str) or (repeat is not None and not isinstance(repeat, str)):
            raise HTTPException(400, "Lokales Passwort fehlt oder ist ungültig.")
        try:
            token = await run_in_threadpool(service.access.unlock, password, repeat)
        except VaultError:
            await run_in_threadpool(service.audit, "LOCAL_UNLOCK_FAILED")
            raise
        await run_in_threadpool(service.audit, "LOCAL_UNLOCKED")
        response = JSONResponse({"authenticated": True, "expires_in_seconds": 900})
        # Loopback HTTP only; remote/TLS access is NOT supported by this application.
        response.set_cookie(
            _COOKIE, token, max_age=900, httponly=True, samesite="strict", path="/api/live"
        )
        return response

    @app.post("/api/live/lock")
    async def lock(request: Request) -> JSONResponse:
        require_session(request)
        service.access.logout()
        await run_in_threadpool(service.audit, "LOCAL_LOCKED")
        response = JSONResponse({"authenticated": False})
        response.delete_cookie(_COOKIE, path="/api/live")
        return response

    @app.post("/api/live/credentials")
    async def save_credentials(request: Request) -> dict[str, object]:
        require_session(request)
        data = await payload(request)
        if data.get("confirmation") != "SCHLUESSEL SPEICHERN":
            raise HTTPException(400, "Schlüsselspeicherung ausdrücklich bestätigen.")
        key, secret = data.get("api_key"), data.get("secret_key")
        if not isinstance(key, str) or not isinstance(secret, str):
            raise HTTPException(400, "API-Key und Secret fehlen oder sind ungültig.")
        credentials = BinanceCredentials(key, secret)

        def save() -> dict[str, object]:
            with service.lock:
                service.require_settled_for_key_change()
                service.audit("BINANCE_CREDENTIAL_SAVE_REQUESTED")
                service.credentials.save(credentials)
                service.invalidate_check()
                service.audit("BINANCE_CREDENTIAL_SAVED", {"fingerprint": credentials.fingerprint})
                return service.credentials.status()

        return await run_in_threadpool(save)

    @app.post("/api/live/credentials/delete")
    async def delete_credentials(request: Request) -> dict[str, bool]:
        require_session(request)
        data = await payload(request)
        if data.get("confirmation") != "SCHLUESSEL ENTFERNEN":
            raise HTTPException(400, "Entfernen des gespeicherten Schlüssels bestätigen.")

        def delete() -> None:
            with service.lock:
                service.require_settled_for_key_change()
                service.audit("BINANCE_CREDENTIAL_DELETE_REQUESTED")
                service.credentials.vault.delete("binance-hmac")
                service.invalidate_check()
                service.audit("BINANCE_CREDENTIAL_REMOVED")

        await run_in_threadpool(delete)
        return {"removed": True, "revoked_at_binance": False}

    @app.post("/api/live/check")
    async def check(request: Request) -> dict[str, object]:
        require_session(request)
        return await run_in_threadpool(service.check)

    @app.post("/api/live/enable")
    async def enable(request: Request) -> dict[str, object]:
        require_session(request)
        data = await payload(request)
        if (
            set(data) != {"confirmation"}
            or data.get("confirmation") != "LIVE MAXIMALBUDGET AKTIVIEREN"
        ):
            raise HTTPException(400, "Livebetrieb mit gespeichertem Maximalbudget bestätigen.")
        try:
            with PaperStore(config.database_path) as store:
                settings = store.load_settings()
            await run_in_threadpool(
                service.enable_live,
                supervisor.state.points(),
                healthy=supervisor.state.snapshot().health == "HEALTHY",
                max_capital=settings.max_capital_usdc,
                emergency_stop=settings.emergency_stop,
            )
        except BinanceCheckError:
            await run_in_threadpool(service.write_diagnostic_report, config.database_path)
            raise
        except (RuntimeError, ValueError, sqlite3.DatabaseError):
            await run_in_threadpool(service.audit, "PRODUCTION_LIVE_ENABLE_FAILED")
            await run_in_threadpool(service.write_diagnostic_report, config.database_path)
            raise HTTPException(
                409,
                "Live-Freigabe fehlgeschlagen. Konto-/Ledger-Abgleich und technische "
                "Freigaben prüfen; es wurde dadurch keine neue Order ausgelöst. "
                "Der Live-Bericht wurde aktualisiert.",
            ) from None
        await run_in_threadpool(service.write_diagnostic_report, config.database_path)
        return get_status(True)

    @app.post("/api/live/disable")
    async def disable(request: Request) -> dict[str, object]:
        require_session(request)
        return await run_in_threadpool(service.stop_entries)

    @app.post("/api/live/trial/start")
    async def start_trial(request: Request) -> JSONResponse:
        require_session(request)
        data = await payload(request)
        if (
            set(data) != {"confirmation", "notional_quote", "quote_asset"}
            or data.get("confirmation") != "TEST 50 USDC"
            or data.get("quote_asset") != "USDC"
            or not isinstance(data.get("notional_quote"), str)
        ):
            raise HTTPException(400, "Genau einen 50-USDC-Test ausdrücklich bestätigen.")
        try:
            amount = Decimal(data["notional_quote"])
            if not amount.is_finite() or amount != Decimal("50"):
                raise ValueError
        except (InvalidOperation, ValueError):
            raise HTTPException(400, "Einmaltest: ausschließlich 50 USDC Kaufbudget.") from None
        try:
            with PaperStore(config.database_path) as store:
                settings = store.load_settings()
            await run_in_threadpool(
                service.start_trial,
                healthy=supervisor.state.snapshot().health == "HEALTHY",
                emergency_stop=settings.emergency_stop,
            )
        except BinanceCheckError:
            await run_in_threadpool(service.write_diagnostic_report, config.database_path)
            raise
        except (RuntimeError, ValueError, sqlite3.DatabaseError) as error:
            await run_in_threadpool(
                service.audit,
                "CONTROLLED_TRIAL_START_FAILED",
                {"error_type": type(error).__name__},
            )
            await run_in_threadpool(service.write_diagnostic_report, config.database_path)
            raise HTTPException(
                409,
                "Der kontrollierte 50-USDC-Test konnte lokal nicht vorbereitet werden. "
                "Es wurde keine neue Order ausgelöst; der Start kann vor einer Order erneut "
                "versucht werden. Der Live-Bericht wurde aktualisiert.",
            ) from None
        await run_in_threadpool(service.write_diagnostic_report, config.database_path)
        return JSONResponse(get_status(True))

    @app.post("/api/live/trial/stop")
    async def stop_trial(request: Request) -> dict[str, object]:
        require_session(request)
        return await run_in_threadpool(service.stop_entries)
